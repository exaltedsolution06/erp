<div class="divider"></div>
<?php if ($this->rbac->hasPrivilege('import_grade', 'can_view')) {
    ?>

    <div class="row">   
        <div class="col-md-9"> 
            <form method="POST" enctype="multipart/form-data" id="fileUploadForm">

                <div class="input-group mb10">
                    <input id="my-file-selector" data-height="34" class="dropify" type="file">
                    <div class="input-group-btn">
                        <input type="submit" class="btn btn-primary" value="<?php echo $this->lang->line('submit') ?>" id="btnSubmit"/>
                    </div>
                </div>
        </div>  
    </form>

    <div class="col-md-3"> 
        <a class="btn btn-primary pull-right" href="<?php echo site_url('admin/examgroup/exportformat') ?>" target="_blank"><i class="fa fa-download"></i> <?php echo $this->lang->line('export') . " " . $this->lang->line('sample'); ?></a>
    </div>
    </div>
    <?php
}
?>


<form method="post" action="<?php echo site_url('admin/coscholasticareas/entrymarks') ?>" id="assign_form1111">
    
    <?php
    if (isset($resultlist) && !empty($resultlist)) {
        ?>
        <div class="row">

            <div class="col-md-12">



                <input type="hidden" name="exam_id" value="<?php echo $exam_id ?>">
                <div class="table-responsive">

                    <table class="table table-striped">
                        <thead>

                            <tr>
                                <th><?php echo $this->lang->line('admission_no'); ?></th>
                                <th><?php echo $this->lang->line('roll_no'); ?></th>
                                <th><?php echo $this->lang->line('student_name'); ?></th> <th><?php echo $this->lang->line('father_name'); ?></th>
                                <th><?php echo $this->lang->line('fee_category'); ?></th>
                                <th><?php echo $this->lang->line('gender'); ?></th>
                                <th><?php echo $this->lang->line('attendence'); ?></th>
								<?php if ($this->rbac->hasPrivilege('add_grade', 'can_add')) { ?>
                                <th><?php echo $this->lang->line('grade').' / '.$this->lang->line('marks') ?></th>
                                <th><?php echo $this->lang->line('note') ?></th>
								<?php } ?>

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if (empty($resultlist)) {
                                ?>
                                <tr>
                                    <td colspan="7" class="text-danger text-center"><?php echo $this->lang->line('no_record_found'); ?></td>
                                </tr>
                                <?php
                            } else {

                                foreach ($resultlist as $student) {
                                    ?>
                                    <tr class="std_adm_<?php echo $student['admission_no']; ?>">
                                <input type="hidden" name="prev_id[<?php echo $student['exam_group_class_batch_exam_students_id'] ?>]" value="<?php echo $student['exam_group_exam_result_id'] ?>">
                                <input type="hidden" name="exam_group_student_id[]" value="<?php echo $student['exam_group_class_batch_exam_students_id'] ?>">
                                <td><?php echo $student['admission_no']; ?></td>
                                <td><?php echo ($student['exam_roll_no'] != 0) ? $student['exam_roll_no'] : '-'; ?></td>
                                <td><?php echo $this->customlib->getFullName($student['firstname'],$student['middlename'],$student['lastname'],$sch_setting->middlename,$sch_setting->lastname);?></td>
                                <td><?php echo $student['father_name']; ?></td>
                                <td><?php echo $student['category']; ?></td>
                                <td><?php echo $student['gender']; ?></td>
                                <td>
                                    <div>

                                        <?php
                                        foreach ($attendence_exam as $attendence_key => $attendence_value) {
                                            $chk = ($student['exam_group_exam_result_attendance'] == $attendence_value) ? "checked='checked'" : "";
                                            ?>
                                            <label class="checkbox-inline"><input type="checkbox" class="attendance_chk" name="exam_group_student_attendance_<?php echo $student['exam_group_class_batch_exam_students_id']; ?>" value="<?php echo $attendence_value; ?>" <?php echo $chk; ?>><?php echo $this->lang->line($attendence_value); ?></label>
                                            <?php
                                        }
                                        ?>

                                    </div>
                                </td>
								<?php if ($this->rbac->hasPrivilege('add_grade', 'can_add')) { ?>
                                <td> <input type="text" class="marksssss form-control" name="exam_group_student_mark_<?php echo $student['exam_group_class_batch_exam_students_id']; ?>" value="<?php echo $student['exam_group_exam_result_get_marks']; ?>" step="any"></td>

                                <td> <input type="text" class="form-control note" name="exam_group_student_note_<?php echo $student['exam_group_class_batch_exam_students_id']; ?>" value="<?php echo $student['exam_group_exam_result_note']; ?>"></td>
								<?php } ?>

                                </tr>
                                <?php
                            }
                        }
                        ?>
                        </tbody></table>

                </div>

                <?php if ($this->rbac->hasPrivilege('exam_marks', 'can_edit')) { ?>
                    <button type="submit" class="allot-fees btn btn-primary btn-sm pull-right" id="load" data-loading-text="<i class='fa fa-spinner fa-spin '></i> Please Wait.."><?php echo $this->lang->line('save'); ?>
                    </button>
                <?php } ?>

                <br/>
                <br/>

            </div>
        </div>
        <?php
    } else {
        ?>

        <div class="alert alert-info">
            <?php echo $this->lang->line('no_record_found'); ?>
        </div>
        <?php
    }
    ?>
</form>