<?php
foreach ($examList as $exam_key => $exam_value) {
    ?>
    <tr>
        <td>
            <?php echo $exam_value->exam; ?>
        </td>
        <td>
            <?php echo $exam_value->session; ?>
        </td>

        <!--<td>
            <?php echo $exam_value->total_subjects; ?>
        </td>-->

        <td class="text text-center">
            <?php echo ($exam_value->is_active == 1) ? "<i class='fa fa-check-square-o'></i>" : "<i class='fa fa-exclamation-circle'></i>"; ?>
        </td>
        <td class="text text-center">
            <?php echo ($exam_value->is_publish == 1) ? "<i class='fa fa-check-square-o'></i>" : "<i class='fa fa-exclamation-circle'></i>"; ?>
        </td>
        <td>
            <?php echo $exam_value->description; ?>
        </td>

        <td class="text-right">

            <?php
            if ($this->rbac->hasPrivilege('co_assign_view_students', 'can_view')) {
                ?>
                <button type="button" data-toggle="tooltip"
                        title = "<?php echo $this->lang->line('assign / view'); ?>" class="btn btn-default btn-xs assignStudent"  id="load" data-examid="<?php echo $exam_value->id; ?>" ><i class="fa fa-tag"></i></button>
                        <?php
                    }
            if ($this->rbac->hasPrivilege('exam_subject', 'can_view')) {
                        ?>
                <!--<button class="btn btn-default btn-xs" id="subjectModalButton" data-toggle="tooltip"   data-exam_id="<?php echo $exam_value->id; ?>"  title="<?php echo $this->lang->line('exam') . " Terms" ?>"><i class="fa fa-book" aria-hidden="true"></i></button>-->
                <?php
            }
            
			if ($this->rbac->hasPrivilege('exam_marks', 'can_view')) {
                ?>
                <!--<button type="button" class="btn btn-default btn-xs examMarksSubject" id="load" data-toggle="tooltip"  data-recordid="<?php echo $exam_value->id; ?>" title="<?php echo $this->lang->line('exam_marks'); ?>" data-loading-text="<i class='fa fa-spinner fa-spin'></i>"><i class="fa fa-newspaper-o"></i></button>-->
				<span data-toggle="tooltip" title="<?php echo $this->lang->line('exam_marks'); ?>">
                    <a href="#" class="btn btn-default btn-xs" data-subject_name="<?php echo $exam_value->exam; ?>" data-exam_id="<?php echo $exam_value->id; ?>" data-toggle="modal" data-target="#subjectModal"><i class="fa fa-newspaper-o"></i></a>
                </span>
                <?php
            }
            
            if ($this->rbac->hasPrivilege('add_exam', 'can_edit')) {
                ?>
                <button class="btn btn-default btn-xs editexamModalButton" data-toggle="tooltip" data-exam_id="<?php echo $exam_value->id; ?>"  title="<?php echo $this->lang->line('edit') ?>"><i class="fa fa-pencil" aria-hidden="true"></i></button>
                <?php
            }
            if ($this->rbac->hasPrivilege('add_exam', 'can_delete')) {
                ?>
                <span data-toggle="tooltip" title="<?php echo $this->lang->line('delete'); ?>">
                    <a href="#" class="btn btn-default btn-xs"  data-id="<?php echo $exam_value->id; ?>" data-exam="<?php echo $exam_value->exam; ?>" id="deleteItem" data-toggle="modal" data-target="#confirm-delete"><i class="fa fa-remove"></i></a>
                </span>
                <?php
            }
            ?>
        </td>
    </tr>
    <?php
}
?>

