<div class="content-wrapper" style="min-height: 946px;">
    <section class="content-header">
        <h1>
            <i class="fa fa-mortar-board"></i> Stock Management <small>Reports</small>        
		</h1>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">             
                <div class="box box-primary">
                    <div class="box-header ptbnull text-center">
                        <h3 class="box-title titlefix">Upcoming Page - Stock Management Reports</h3>
                    </div>
                </div>
            </div> 

        </div> 
    </section>
</div>