<div class="content-wrapper" style="min-height: 946px;">
    <section class="content-header">
        <h1>
            <i class="fa fa-mortar-board"></i> Online Exam <small>Reports</small>        
		</h1>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">             
                <div class="box box-primary">
                    <div class="box-header ptbnull text-center">
                        <h3 class="box-title titlefix">Upcoming Page - Online Exam Reports</h3>
                    </div>
                </div>
            </div> 

        </div> 
    </section>
</div>