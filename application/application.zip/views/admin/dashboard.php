<?php $currency_symbol = $this->customlib->getSchoolCurrencyFormat(); ?>
<style type="text/css">
    .borderwhite{border-top-color: #fff !important;}
    .box-header>.box-tools {display: none;}
    .sidebar-collapse #barChart{height: 100% !important;}
    .sidebar-collapse #lineChart{height: 100% !important;}
</style>
<div class="content-wrapper" style="min-height: 946px;">
    <section class="content">
        
        <div class="dashalertpay alert alert-danger alert-dismissible" role="alert">
			<a class="link pull-right" autocomplete="off">Pay Now</a>
			Important notice! payment due
		</div>
        
        
        
        
        
        
        
        <div class="">

            <!--<div class="alert alert-danger">-->
            <!--    Smart School may not work properly because ONLY_FULL_GROUP_BY is enabled, consult with your hosting provider to disable ONLY_FULL_GROUP_BY in sql_mode configuration.-->
            <!--</div>-->
        
            <?php foreach ($notifications as $notice_value) { ?>
                <div class="dashalert alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="alertclose close close_notice" data-dismiss="alert" aria-label="Close" data-noticeid="<?php echo $notice_value->id; ?>"><span aria-hidden="true">&times;</span></button>
                    <a href="<?php echo site_url('admin/notification') ?>"><?php echo $notice_value->title; ?></a>
                </div>
            <?php } ?>
        
        </div> 
        
        <div class="row">    
			<?php foreach ($roles as $key => $value) { ?>
			<div class="col-lg-3 col-md-3 col-sm-12 col201">
					<div class="info-box">
						<a href="#">
							<span class="info-box-icon bg-own">
							<?php if($key == 'Admin') { ?>
							<i class="fa-solid fa-user-tie"></i>
							<?php } else if($key == 'Teacher') { ?>
							<i class="fa-solid fa-person-chalkboard"></i>
							<?php } else if($key == 'Accountant') { ?>
							<i class="fa-solid fa-user-shield"></i>
							<?php } else if($key == 'Librarian') { ?>
							<i class="fa-solid fa-address-book"></i>
							<?php } else if($key == 'Receptionist') { ?>
							<i class="fa-solid fa-person-shelter"></i>
							<?php } else if($key == 'Super Admin') { ?>
							<i class="fa-solid fa-user-gear"></i>
							<?php } else { ?>
							<i class="fa-solid fa-user-tie"></i>
							<?php } ?>
							</span>
							<div class="info-box-content">
								<span class="info-box-text"><?php echo $key; ?></span>
								<span class="info-box-number"><?php echo $value; ?></span>
							</div>
						</a>
					</div>  
			</div><!--./col-lg-3-->   
            <?php } ?>
			<?php if ($this->rbac->hasPrivilege('student_count_widget', 'can_view')) { ?>
			<div class="col-lg-3 col-md-3 col-sm-12">
				<div class="info-box">
					<a href="<?php echo site_url('student/search') ?>">
						<span class="info-box-icon bg-own"><i class="fa-solid fa-user-graduate"></i></span>
						<div class="info-box-content">
							<span class="info-box-text"><?php echo $this->lang->line('student'); ?></span>
							<span class="info-box-number"><?php echo $total_students; ?></span>
						</div>
					</a>
				</div>
			</div>
			<?php } ?>
		</div>  
		<div class="row row-flex3">	
			<div class="col-md-3 col-sm-6 mb10">
				<div class="topprograssstart flex-card">
					<h5 class="pro-border">Total student</h5>
					<p class="text-uppercase mt10 clearfix">Total Male Student<span class="pull-right"><?php echo isset($total_male_students) ? $total_male_students : 0;  ?></span>
					</p>
					<div class="progress-group">
						<div class="progress progress-minibar">
							<div class="progress-bar" style="width: <?php echo round($total_male_percent) ?>%"></div>
						</div>
					</div>
					<p class="text-uppercase mt10 clearfix">Total Female Student<span class="pull-right"><?php echo isset($total_female_students) ? $total_female_students : 0;  ?></span>
					</p>
					<div class="progress-group">
						<div class="progress progress-minibar">
							<div class="progress-bar progress-bar-aqua" style="width: <?php echo round($total_female_percent) ?>%"></div>
						</div>
					</div>
					<p class="text-uppercase mt10 clearfix">Total Student<span class="pull-right"><?php echo isset($total_male_female_student) ? $total_male_female_student: ''; ?></span>
					</p>
				</div>
			</div>
			
			<div class="col-md-3 col-sm-6 mb10">
				<div class="topprograssstart flex-card">
					<h5 class="pro-border">Today's Total collection</h5>
					<p class="text-uppercase mt10 clearfix">Collection<span class="pull-right"><?php echo isset($studentAcademicColls) ? format_amount($studentAcademicColls) : 0;  ?></span>
					</p>
					<div class="progress-group">
						<div class="progress progress-minibar">
							<div class="progress-bar progress-bar-green" style="width: <?php echo round($studentAcademicCollsPercent) ?>%"></div>
						</div>
					</div>
					<!--<p class="text-uppercase mt10 clearfix">Transport Collection<span class="pull-right"><?php echo isset($studentTransportColls) ? $studentTransportColls : 0;  ?></span>
					</p>
					<div class="progress-group">
						<div class="progress progress-minibar">
							<div class="progress-bar progress-bar-purple" style="width: <?php echo round($studentTransportCollsPercent) ?>%"></div>
						</div>
					</div>-->
					<p class="text-uppercase mt10 clearfix">Other Collection<span class="pull-right"><?php echo isset($today_other_collection) ? format_amount($today_other_collection) : 0;  ?></span>
					</p>
					<div class="progress-group">
						<div class="progress progress-minibar">
							<div class="progress-bar progress-bar-aqua" style="width: <?php echo round($studentOtherCollsPercent) ?>%"></div>
						</div>
					</div>
					<p class="text-uppercase mt10 clearfix">Today's Total collection<span class="pull-right"><?php echo isset($todayTotalCollection) ? format_amount($today_total_income) : ''; ?></span>
					</p>
				</div>
			</div>
			
			<div class="col-md-3 col-sm-6 mb10">
				<div class="topprograssstart flex-card">
					<h5 class="pro-border">Today's Financial Summary</h5>
					<p class="text-uppercase mt10 clearfix">Todays income<span class="pull-right"><?php echo isset($today_total_income) ? format_amount($today_total_income) : 0;  ?></span>
					</p>
					<div class="progress-group">
						<div class="progress progress-minibar">
							<div class="progress-bar progress-bar-purple" style="width: <?php echo round($total_income_percent) ?>%"></div>
						</div>
					</div>
					<p class="text-uppercase mt10 clearfix">Todays expense<span class="pull-right"><?php echo isset($today_total_expense) ? format_amount($today_total_expense) : 0;  ?></span>
					</p>
					<div class="progress-group">
						<div class="progress progress-minibar">
							<div class="progress-bar progress-bar-green" style="width: <?php echo round($total_expense_percent) ?>%"></div>
						</div>
					</div>
					<p class="text-uppercase mt10 clearfix">Net cash in hand<span class="pull-right"><?php echo isset($net_cash_in_hands) ? format_amount($net_cash_in_hands) : ''; ?></span>
					</p>
				</div>
			</div>
			<div class="col-md-3 col-sm-6 mb10">
				<div class="topprograssstart flex-card">
					<h5 class="pro-border">Todays Total attendance</h5>
					<p class="text-uppercase mt10 clearfix">Total Present<span class="pull-right"><?php echo isset($total_present_student) ? $total_present_student : 0;  ?></span>
					</p>
					<div class="progress-group">
						<div class="progress progress-minibar">
							<div class="progress-bar  progress-bar-red" style="width: <?php echo round($total_present_percent) ?>%"></div>
						</div>
					</div>
					<p class="text-uppercase mt10 clearfix">Total Absent<span class="pull-right"><?php echo isset($total_absent_student) ? $total_absent_student : 0;  ?></span>
					</p>
					<div class="progress-group">
						<div class="progress progress-minibar">
							<div class="progress-bar progress-bar-aqua" style="width: <?php echo round($total_absent_percent) ?>%"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-3 col-sm-6 mb10">
				<div class="topprograssstart flex-card">
					<h5 class="pro-border">Previous balance</h5>
					<p class="text-uppercase mt10 clearfix">Total <span class="pull-right"><?php echo isset($tot_prev_balance) ? $tot_prev_balance : 0;  ?></span>
					</p>
					<p class="text-uppercase mt10 clearfix">Total Collected <span class="pull-right"><?php echo isset($collected_prev_balance) ? $collected_prev_balance : 0;  ?></span>
					</p>
					<div class="progress-group">
						<div class="progress progress-minibar">
							<div class="progress-bar progress-bar-success" style="width: <?php echo $tot_prev_balance > 0 ? round(($collected_prev_balance/$tot_prev_balance) * 100) : 0 ?>%"></div>
						</div>
					</div>
					<p class="text-uppercase mt10 clearfix">Remaining <span class="pull-right"><?php echo isset($remain_prev_balance) ? $remain_prev_balance : 0;  ?></span>
					</p>
					<div class="progress-group">
						<div class="progress progress-minibar">
							<div class="progress-bar progress-bar-red" style="width: <?php echo $tot_prev_balance > 0 ? round(($remain_prev_balance/$tot_prev_balance) * 100) : 0 ?>%"></div>
						</div>
					</div>
					<p class="text-uppercase mt10 clearfix">Today's total collected<span class="pull-right"><?php echo isset($today_collected_balance) ? $today_collected_balance : 0;  ?></span>
					</p>
				</div>
			</div>
			<div class="col-md-3 col-sm-6 mb10">
				<div class="topprograssstart flex-card">
					<h5 class="pro-border">Tickets</h5>
					<p class="text-uppercase mt10 clearfix">Total Tickets <span class="pull-right"><?php echo isset($ticketcounter) ? $ticketcounter['total'] : 0;  ?></span>
					</p>
					<p class="text-uppercase mt10 clearfix">Pending Tickets <span class="pull-right"><?php echo isset($ticketcounter) ? $ticketcounter['pending'] : 0;  ?></span>
					</p>
					<div class="progress-group">
						<div class="progress progress-minibar">
							<div class="progress-bar progress-bar-warning" style="width: <?php echo $ticketcounter['total'] > 0 ? round(($ticketcounter['pending']/$ticketcounter['total']) * 100) : 0 ?>%"></div>
						</div>
					</div>
					<p class="text-uppercase mt10 clearfix">Open Tickets <span class="pull-right"><?php echo isset($ticketcounter) ? $ticketcounter['open'] : 0;  ?></span>
					</p>
					<div class="progress-group">
						<div class="progress progress-minibar">
							<div class="progress-bar progress-bar-primary" style="width: <?php echo $ticketcounter['total'] > 0 ? round(($ticketcounter['open']/$ticketcounter['total']) * 100) : 0 ?>%"></div>
						</div>
					</div>
					<p class="text-uppercase mt10 clearfix">Close Tickets <span class="pull-right"><?php echo isset($ticketcounter) ? $ticketcounter['close'] : 0;  ?></span>
					</p>
					<div class="progress-group">
						<div class="progress progress-minibar">
							<div class="progress-bar progress-bar-success" style="width: <?php echo $ticketcounter['total'] > 0 ? round(($ticketcounter['close']/$ticketcounter['total']) * 100) : 0 ?>%"></div>
						</div>
					</div>
				</div>
			</div>
		</div>  
				
       <!-- <div class="row">    
        
        <?php
        $currency_symbol = $this->customlib->getSchoolCurrencyFormat();
        $div_col = 9;
        $div_rol = 12;
        $bar_chart = true;
        $line_chart = true;
        
        $widget_col = array(0 => 1, 1 => 2, 2 => 3);
        $widget = 4;
        ?> 
        
        
        
            <div class="col-lg-12 col-md-12 col-sm-12 col801">
                <div class="row">
					<?php if ($this->rbac->hasPrivilege('monthly_fees_collection_widget', 'can_view')) { ?>
                    <div class="col-md-4 col-sm-6">
                        <div class="info-box">
                            <a href="<?php echo site_url('studentfee') ?>">
                                <span class="info-box-icon bg-green"><i class="fa fa-money"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo $this->lang->line('monthly_fees_collection'); ?></span>
                                    <span class="info-box-number"><?php echo $currency_symbol . $month_collection; ?></span>
                                </div>
                            </a>
                        </div>
                    </div>
					<?php } if ($this->rbac->hasPrivilege('monthly_expense_widget', 'can_view')) { ?>
                    <div class="col-md-4 col-sm-6">
                        <div class="info-box">
                            <a href="<?php echo site_url('admin/expense') ?>">
                                <span class="info-box-icon bg-red"><i class="fa fa-credit-card"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo $this->lang->line('yearly_expenses'); ?></span>
                                    <span class="info-box-number"><?php echo $currency_symbol . $yearly_expenses; ?></span>
                                </div>
                            </a>
                        </div>
                    </div>
					<?php } if ($this->rbac->hasPrivilege('student_count_widget', 'can_view')) { ?>
                    <div class="col-md-4 col-sm-6">
                        <div class="info-box">
                            <a href="<?php echo site_url('student/search') ?>">
                                <span class="info-box-icon bg-aqua"><i class="fa fa-user"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo $this->lang->line('student'); ?></span>
                                    <span class="info-box-number"><?php echo $total_students; ?></span>
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php } if ($this->rbac->hasPrivilege('monthly_fees_collection_widget', 'can_view')) { ?>
                    <div class="col-md-4 col-sm-6">
                        <div class="info-box">
                            <a href="<?php echo site_url('studentfee') ?>">
                                <span class="info-box-icon bg-green"><i class="fa fa-money"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo $this->lang->line('monthly_fees_collection'); ?></span>
                                    <span class="info-box-number"><?php echo $currency_symbol . $month_collection; ?></span>
                                </div>
                            </a>
                        </div>
                    </div>
					<?php } if ($this->rbac->hasPrivilege('monthly_expense_widget', 'can_view')) { ?>
                    <div class="col-md-4 col-sm-6">
                        <div class="info-box">
                            <a href="<?php echo site_url('admin/expense') ?>">
                                <span class="info-box-icon bg-red"><i class="fa fa-credit-card"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo $this->lang->line('monthly_expenses'); ?></span>
                                    <span class="info-box-number"><?php echo $currency_symbol . $month_expense; ?></span>
                                </div>
                            </a>
                        </div>
                    </div>
					<?php } if ($this->rbac->hasPrivilege('student_count_widget', 'can_view')) { ?>
                    <div class="col-md-4 col-sm-6">
                        <div class="info-box">
                            <a href="<?php echo site_url('student/search') ?>">
                                <span class="info-box-icon bg-aqua"><i class="fa fa-user"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo $this->lang->line('student'); ?></span>
                                    <span class="info-box-number"><?php echo $total_students; ?></span>
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php } if ($this->rbac->hasPrivilege('monthly_fees_collection_widget', 'can_view')) { ?>
                    <div class="col-md-4 col-sm-6">
                        <div class="info-box">
                            <a href="<?php echo site_url('studentfee') ?>">
                                <span class="info-box-icon bg-green"><i class="fa fa-money"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo $this->lang->line('monthly_fees_collection'); ?></span>
                                    <span class="info-box-number"><?php echo $currency_symbol . $month_collection; ?></span>
                                </div>
                            </a>
                        </div>
                    </div>
					<?php } if ($this->rbac->hasPrivilege('monthly_expense_widget', 'can_view')) { ?>
                    <div class="col-md-4 col-sm-6">
                        <div class="info-box">
                            <a href="<?php echo site_url('admin/expense') ?>">
                                <span class="info-box-icon bg-red"><i class="fa fa-credit-card"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo $this->lang->line('weekly_expenses'); ?></span>
                                    <span class="info-box-number"><?php echo $currency_symbol . $weekly_expense; ?></span>
                                </div>
                            </a>
                        </div>
                    </div>
					<?php } if ($this->rbac->hasPrivilege('student_count_widget', 'can_view')) { ?>
                    <div class="col-md-4 col-sm-6">
                        <div class="info-box">
                            <a href="<?php echo site_url('student/search') ?>">
                                <span class="info-box-icon bg-aqua"><i class="fa fa-user"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo $this->lang->line('student'); ?></span>
                                    <span class="info-box-number"><?php echo $total_students; ?></span>
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php } if ($this->rbac->hasPrivilege('monthly_fees_collection_widget', 'can_view')) { ?>
                    <div class="col-md-4 col-sm-6">
                        <div class="info-box">
                            <a href="<?php echo site_url('studentfee') ?>">
                                <span class="info-box-icon bg-green"><i class="fa fa-money"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo $this->lang->line('monthly_fees_collection'); ?></span>
                                    <span class="info-box-number"><?php echo $currency_symbol . $month_collection; ?></span>
                                </div>
                            </a>
                        </div>
                    </div>
					<?php } if ($this->rbac->hasPrivilege('monthly_expense_widget', 'can_view')) { ?>
                    <div class="col-md-4 col-sm-6">
                        <div class="info-box">
                            <a href="<?php echo site_url('admin/expense') ?>">
                                <span class="info-box-icon bg-red"><i class="fa fa-credit-card"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo $this->lang->line('total_expenses'); ?></span>
                                    <span class="info-box-number"><?php echo $currency_symbol . $total_expenses; ?></span>
                                </div>
                            </a>
                        </div>
                    </div>
					<?php } ?>
				</div>  	
				 
        
                
        
            </div>
			
			
        
            
        
        </div><!--./row-->
		
				<div class="row">
                        <div class="col-lg-7 col-md-7 col-sm-12 col60">
							<div class="box box-primary borderwhite">
								<div class="box-header with-border">
									<h3 class="box-title">Income &amp; Expenses For <?php echo date('F Y'); ?></h3>
									
								</div>
								<div class="box-body">
									<div class="chart">
									  <canvas id="barChart" height="200" width="583" style="width: 583px; height: 200px;"></canvas>
									</div>
								</div>
							</div>
						</div><!--./col-lg-7-->
                        <div class="col-lg-5 col-md-5 col-sm-12 col40">
							<div class="box box-primary borderwhite">
								<div class="box-header with-border"><h3 class="box-title">Income - <?php echo date('F Y'); ?></h3></div>
								<div class="box-body">
									<div class="chart-responsive"><iframe class="chartjs-hidden-iframe" style="display: block; overflow: hidden; border: 0px; margin: 0px; inset: 0px; height: 100%; width: 100%; position: absolute; pointer-events: none; z-index: -1;" tabindex="-1"></iframe>
										<canvas id="doughnut-chart" class="pb20" height="200" style="display: block; width: 401px; height: 200px;" width="401"></canvas>
									</div>
								</div>
							</div><!--./col-md-6-->
						</div><!--./col-lg-5-->
				</div>
				<div class="row">
                    <div class="col-lg-7 col-md-7 col-sm-12 col60">
                        <div class="box box-info borderwhite">
                            <div class="box-header with-border">
                                <h3 class="box-title">Income &amp; Expenses For Session 2025-26</h3>
                                <div class="box-tools pull-right">
                                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                                </div>
                            </div>
                            <div class="box-body">
                                <div class="chart">
                                      <canvas id="lineChart" height="200" width="583" style="width: 583px; height: 200px;"></canvas>
                                </div>
                            </div>
                        </div>
                    </div><!--./col-lg-7-->
                    <div class="col-lg-5 col-md-5 col-sm-12 col40">
                        <div class="box box-primary borderwhite">
                            <div class="box-header with-border"><h3 class="box-title">Expense - <?php echo date('F Y'); ?></h3>
                            </div><!--./info-box-->
                            <div class="box-body">
                                <div class="chart-responsive"><iframe class="chartjs-hidden-iframe" style="display: block; overflow: hidden; border: 0px; margin: 0px; inset: 0px; height: 100%; width: 100%; position: absolute; pointer-events: none; z-index: -1;" tabindex="-1"></iframe>
                                    <canvas id="doughnut-chart1" class="pb20" height="200" style="display: block; width: 401px; height: 200px;" width="401"></canvas>
                                </div>
                            </div>
                        </div>
                    </div><!--./col-lg-5-->
				</div>
        
		<div class="row">
			<div class="col-md-12">
				<div class="box box-primary borderwhite">
					<div class="box-body">
						<!-- THE CALENDAR -->
						<div id="calendar"></div>
					</div>
				</div>
			</div>
		</div>

        
        </section>
        
        </div>
        
        
        <?php /*
        
        <div class="">

            <?php if ($mysqlVersion && $sqlMode && strpos($sqlMode->mode, 'ONLY_FULL_GROUP_BY') !== FALSE) { ?>
                <div class="alert alert-danger">
                    Smart School may not work properly because ONLY_FULL_GROUP_BY is enabled, consult with your hosting provider to disable ONLY_FULL_GROUP_BY in sql_mode configuration.
                </div>
            <?php } ?>

            <?php
            $show = false;
            $role = $this->customlib->getStaffRole();
            $role_id = json_decode($role)->id;
            foreach ($notifications as $notice_key => $notice_value) {

                if ($role_id == 7) {
                    $show = true;
                } elseif (date($this->customlib->getSchoolDateFormat()) >= date($this->customlib->getSchoolDateFormat(), $this->customlib->dateyyyymmddTodateformat($notice_value->publish_date))) {
                    $show = true;
                }
                if ($show) {
                    ?>

                    <div class="dashalert alert alert-success alert-dismissible" role="alert">
                        <button type="button" class="alertclose close close_notice" data-dismiss="alert" aria-label="Close" data-noticeid="<?php echo $notice_value->id; ?>"><span aria-hidden="true">&times;</span></button>

                        <a href="<?php echo site_url('admin/notification') ?>"><?php echo $notice_value->title; ?></a>
                    </div>

                    <?php
                }
            }
            ?>

        </div> 
     

         
        



        <div class="row">    


        <?php


            $currency_symbol = $this->customlib->getSchoolCurrencyFormat();

            $div_col = 12;
            $div_rol = 12;
            $bar_chart = true;
            $line_chart = true;
            if ($this->rbac->hasPrivilege('staff_role_count_widget', 'can_view')) {
                $div_col = 9;
                $div_rol = 12;
            }

            $widget_col = array();
            if ($this->rbac->hasPrivilege('Monthly fees_collection_widget', 'can_view')) {
                $widget_col[0] = 1;
                $div_rol = 3;
            }

            if ($this->rbac->hasPrivilege('monthly_expense_widget', 'can_view')) {
                $widget_col[1] = 2;
                $div_rol = 3;
            }

            if ($this->rbac->hasPrivilege('student_count_widget', 'can_view')) {
                $widget_col[2] = 3;
                $div_rol = 3;
            }
            $div = sizeof($widget_col);
            if (!empty($widget_col)) {
                $widget = 12 / $div;
            } else {

                $widget = 12;
            }
            ?> 


            <div class="row">

                <div class="col-lg-9 col-md-9 col-sm-12 col80">
                    <div class="row">
<?php
if ($this->module_lib->hasActive('fees_collection')) {
    if ($this->rbac->hasPrivilege('Monthly fees_collection_widget', 'can_view')) {
        ?>
                                <div class="col-md-4 col-sm-6">
                                    <div class="info-box">
                                        <a href="<?php echo site_url('studentfee') ?>">
                                            <span class="info-box-icon bg-green"><i class="fa fa-money"></i></span>
                                            <div class="info-box-content">
                                                <span class="info-box-text"><?php echo $this->lang->line('monthly_fees_collection'); ?></span>
                                                <span class="info-box-number"><?php echo $currency_symbol . $month_collection; ?></span>
                                            </div>
                                        </a>
                                    </div>
                                </div>
    <?php }
}
?>
<?php
if ($this->module_lib->hasActive('expense')) {
    if ($this->rbac->hasPrivilege('monthly_expense_widget', 'can_view')) {
        ?>

                                <div class="col-md-4 col-sm-6">
                                    <div class="info-box">
                                        <a href="<?php echo site_url('admin/expense') ?>">
                                            <span class="info-box-icon bg-red"><i class="fa fa-credit-card"></i></span>
                                            <div class="info-box-content">
                                                <span class="info-box-text"><?php echo $this->lang->line('monthly_expenses'); ?></span>
                                                <span class="info-box-number"><?php echo $currency_symbol . $month_expense; ?></span>
                                            </div>
                                        </a>
                                    </div>
                                </div>
    <?php
    }
}

if ($this->rbac->hasPrivilege('student_count_widget', 'can_view')) {
    ?>


                            <div class="col-md-4 col-sm-6">
                                <div class="info-box">
                                    <a href="<?php echo site_url('student/search') ?>">
                                        <span class="info-box-icon bg-aqua"><i class="fa fa-user"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text"><?php echo $this->lang->line('student'); ?></span>
                                            <span class="info-box-number"><?php echo $total_students; ?></span>
                                        </div>
                                    </a>
                                </div>
                            </div>
<?php } ?>
                    </div>   


<?php
if ($this->rbac->hasPrivilege('calendar_to_do_list', 'can_view')) {
    $div_rol = 3;
    ?>
                        <div class="box box-primary borderwhite">
                            <div class="box-body">
                                <!-- THE CALENDAR -->
                                <div id="calendar"></div>
                            </div>
                            <!-- /.box-body -->
                        </div>
                        <!-- /. box -->
                    <?php } ?> 

                </div><!--./col-lg-9-->
<?php
if ($this->rbac->hasPrivilege('staff_role_count_widget', 'can_view')) {
    // print_r($roles);
    ?>

                    <div class="col-lg-3 col-md-3 col-sm-12 col20">

    <?php foreach ($roles as $key => $value) {
        ?>
                            <div class="info-box">
                                <a href="#">
                                    <span class="info-box-icon bg-yellow"><i class="fa fa-user-secret"></i></span>
                                    <div class="info-box-content">
                                        <span class="info-box-text"><?php echo $key; ?></span>
                                        <span class="info-box-number"><?php echo $value; ?></span>
                                    </div>
                                </a>
                            </div>     
    <?php } ?>



                    </div><!--./col-lg-3-->
<?php } ?>
            </div><!--./row-->








        </div><!--./row-->


</div>
        
        
        
        
        
        
    */    ?>
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        











<div id="newEventModal" class="modal fade " role="dialog">
    <div class="modal-dialog modal-dialog2 modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"><?php echo $this->lang->line("add_new_event"); ?></h4>
            </div>
            <div class="modal-body">

                <div class="row">
                    <form role="form"  id="addevent_form" method="post" enctype="multipart/form-data" action="">
                        <div class="form-group col-md-12">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event'); ?> <?php echo $this->lang->line('title'); ?></label><small class="req"> *</small>
                            <input class="form-control" name="title" id="input-field"> 
                            <span class="text-danger"><?php echo form_error('title'); ?></span>

                        </div>

                        <div class="form-group col-md-12">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('description'); ?></label>
                            <textarea name="description" class="form-control" id="desc-field"></textarea></div>
                     <div class="row">
                                
                        <div class="form-group col-md-6">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event')." ".$this->lang->line('from')?></label>
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" autocomplete="off" name="event_from" class="form-control pull-right event_from">
                            </div>
                        </div>

                        <div class="form-group col-md-6">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event')." ".$this->lang->line('to')?></label>
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" autocomplete="off" name="event_to" class="form-control pull-right event_to">
                            </div>
                        </div>
                            </div>
                        <div class="form-group col-md-12">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event'); ?> <?php echo $this->lang->line('color'); ?></label>
                            <input type="hidden" name="eventcolor" autocomplete="off" id="eventcolor" class="form-control">
                        </div>
                        <div class="form-group col-md-12">
                            <?php //print_r($event_colors)   ?>

                            <?php
                            $i = 0;
                            $colors = '';
                            foreach ($event_colors as $color) {
                                $color_selected_class = 'cpicker-small';
                                if ($i == 0) {
                                    $color_selected_class = 'cpicker-big';
                                }
                                $colors .= "<div class='calendar-cpicker cpicker " . $color_selected_class . "' data-color='" . $color . "' style='background:" . $color . ";border:1px solid " . $color . "; border-radius:100px'></div>";
                                //   echo $colors ;
                                $i++;
                            }
                            echo '<div class="cpicker-wrapper">';
                            echo $colors;
                            echo '</div>';
                            ?>
                        </div>

                        <div class="form-group col-md-12">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event'); ?> <?php echo $this->lang->line('type'); ?></label>
                            <br/>
                            <label class="radio-inline">

                                <input type="radio" name="event_type" value="public" id="public"><?php echo $this->lang->line('public'); ?>
                            </label>
                            <label class="radio-inline">

                                <input type="radio" name="event_type" value="private" checked id="private"><?php echo $this->lang->line('private'); ?>
                            </label>
                            <label class="radio-inline">

                                <input type="radio" name="event_type" value="sameforall" id="public"><?php echo $this->lang->line('all'); ?> <?php echo json_decode($role)->name; ?>
                            </label>
                            <label class="radio-inline">

                                <input type="radio" name="event_type" value="protected" id="public"><?php echo $this->lang->line('protected'); ?>
                            </label> </div>

                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <input type="submit" class="btn btn-primary submit_addevent pull-right" value="<?php echo $this->lang->line('save'); ?>"></div> </form>
                </div>

            </div>
        </div>
    </div>
</div>  











<div id="viewEventModal" class="modal fade " role="dialog">
    <div class="modal-dialog modal-dialog2 modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"><?php echo $this->lang->line('edit') ?> <?php echo $this->lang->line('event') ?></h4>
            </div>
            <div class="modal-body">

                <div class="row">
                    <form role="form"   method="post" id="updateevent_form"  enctype="multipart/form-data" action="" >
                        <div class="form-group col-md-12">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event') ?><?php echo $this->lang->line('title') ?></label>
                            <input class="form-control" name="title" placeholder="" id="event_title"> 
                        </div>
                        <div class="form-group col-md-12">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('description') ?></label>
                            <textarea name="description" class="form-control" placeholder="" id="event_desc"></textarea></div>
                      <div class="row">
                                
                        <div class="form-group col-md-6">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event')." ".$this->lang->line('from')?></label>
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" autocomplete="off" name="event_from" class="form-control pull-right event_from">
                            </div>
                        </div>

                        <div class="form-group col-md-6">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event')." ".$this->lang->line('to')?></label>
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" autocomplete="off" name="event_to" class="form-control pull-right event_to">
                            </div>
                        </div>
                            </div>
                        <input type="hidden" name="eventid" id="eventid">
                        <div class="form-group col-md-12">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event') ?><?php echo $this->lang->line('color') ?></label>
                            <input type="hidden" name="eventcolor" autocomplete="off" placeholder="Event Color" id="event_color" class="form-control">
                        </div>
                        <div class="form-group col-md-12">
                            <?php //print_r($event_colors)  ?>

                            <?php
                            $i = 0;
                            $colors = '';
                            foreach ($event_colors as $color) {
                                $colorid = trim($color, "#");
                                // print_r($colorid);
                                $color_selected_class = 'cpicker-small';
                                if ($i == 0) {
                                    $color_selected_class = 'cpicker-big';
                                }
                                $colors .= "<div id=" . $colorid . " class='calendar-cpicker cpicker " . $color_selected_class . "' data-color='" . $color . "' style='background:" . $color . ";border:1px solid " . $color . "; border-radius:100px'></div>";
                                //   echo $colors ;
                                $i++;
                            }
                            echo '<div class="cpicker-wrapper selectevent">';
                            echo $colors;
                            echo '</div>';
                            ?>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event') ?><?php echo $this->lang->line('type') ?></label>
                            <label class="radio-inline">

                                <input type="radio" name="eventtype" value="public" id="public"><?php echo $this->lang->line('public') ?>
                            </label>
                            <label class="radio-inline">

                                <input type="radio" name="eventtype" value="private" id="private"><?php echo $this->lang->line('private') ?> 
                            </label>
                            <label class="radio-inline">

                                <input type="radio" name="eventtype" value="sameforall" id="public"><?php echo $this->lang->line('all') ?> <?php echo json_decode($role)->name; ?>
                            </label>
                            <label class="radio-inline">

                                <input type="radio" name="eventtype" value="protected" id="public"><?php echo $this->lang->line('protected') ?> 
                            </label>
                        </div>

                        <div class="col-xs-11 col-sm-11 col-md-11 col-lg-11">

                            <input type="submit" class="btn btn-primary submit_update pull-right" value="<?php echo $this->lang->line('save'); ?>">
                        </div>
                        <div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">
<?php if ($this->rbac->hasPrivilege('calendar_to_do_list', 'can_delete')) { ?>
                                <input type="button" id="delete_event" class="btn btn-primary submit_delete pull-right" value="<?php echo $this->lang->line('delete'); ?>">
<?php } ?>
                        </div>       
                    </form>
                </div>

            </div>
        </div>
    </div>
</div>
<style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
<!-- <script src="<?php echo base_url() ?>backend/js/Chart.min.js"></script>
<script src="<?php echo base_url() ?>backend/js/utils.js"></script> -->
<script type="text/javascript">

    new Chart(document.getElementById("doughnut-chart"), {
    type: 'doughnut',
            data: {
            labels: [<?php foreach ($incomegraph as $value) { ?>"<?php echo $value['income_category']; ?>", <?php } ?> ],
                    datasets: [
                    {
                    label: "Income",
                            backgroundColor: [<?php $s = 1;
foreach ($incomegraph as $value) {
    ?>"<?php echo incomegraphColors($s++); ?>", <?php
    if ($s == 8) {
        $s = 1;
    }
}
?> ],
                            data: [<?php $s = 1;
foreach ($incomegraph as $value) {
    ?><?php echo $value['total']; ?>, <?php } ?>]
                    }
                    ]
            },
            options: {
            responsive: true,
                    circumference: Math.PI,
                    rotation: - Math.PI,
                    legend: {
                    position: 'top',
                    },
                    title: {
                    display: true,
                    },
                    animation: {
                    animateScale: true,
                            animateRotate: true
                    }
            }
    });
    new Chart(document.getElementById("doughnut-chart1"), {
    type: 'doughnut',
            data: {
            labels: [<?php foreach ($expensegraph as $value) { ?>"<?php echo $value['exp_category']; ?>", <?php } ?>],
                    datasets: [
                    {
                    label: "Population (millions)",
                            backgroundColor: [<?php $ss = 1;
foreach ($expensegraph as $value) {
    ?>"<?php echo expensegraphColors($ss++); ?>", <?php
    if ($ss == 8) {
        $ss = 1;
    }
}
?>],
                            data: [<?php foreach ($expensegraph as $value) { ?><?php echo $value['total']; ?>, <?php } ?>]
                    }
                    ]
            },
            options: {
            responsive: true,
                    circumference: Math.PI,
                    rotation: - Math.PI,
                    legend: {
                    position: 'top',
                    },
                    title: {
                    display: true,
                    },
                    animation: {
                    animateScale: true,
                            animateRotate: true
                    }
            }
    });
<?php
//if (($this->module_lib->hasActive('fees_collection')) || ($this->module_lib->hasActive('expense'))) {
    ?>
        $(function () {
        var areaChartOptions = {
        showScale: true,
                scaleShowGridLines: false,
                scaleGridLineColor: "rgba(0,0,0,.05)",
                scaleGridLineWidth: 1,
                scaleShowHorizontalLines: true,
                scaleShowVerticalLines: true,
                bezierCurve: true,
                bezierCurveTension: 0.3,
                pointDot: false,
                pointDotRadius: 4,
                pointDotStrokeWidth: 1,
                pointHitDetectionRadius: 20,
                datasetStroke: true,
                datasetStrokeWidth: 2,
                datasetFill: true,
                maintainAspectRatio: true,
                responsive: true
        };
        var bar_chart = "<?php echo $bar_chart ?>";
        var line_chart = "<?php echo $line_chart ?>";
        if (line_chart) {


        var lineChartCanvas = $("#lineChart").get(0).getContext("2d");
        var lineChart = new Chart(lineChartCanvas);
        var lineChartOptions = areaChartOptions;
        lineChartOptions.datasetFill = false;
        var yearly_collection_array = <?php echo json_encode($yearly_collection) ?>;
        var yearly_expense_array = <?php echo json_encode($yearly_expense) ?>;
        var total_month = <?php echo json_encode($total_month) ?>;
        var areaChartData_expense_Income = {
        labels: total_month,
                datasets: [
                {
                label: "Expense",
                        fillColor: "rgba(215, 44, 44, 0.7)",
                        strokeColor: "rgba(215, 44, 44, 0.7)",
                        pointColor: "rgba(233, 30, 99, 0.9)",
                        pointStrokeColor: "#c1c7d1",
                        pointHighlightFill: "#fff",
                        pointHighlightStroke: "rgba(220,220,220,1)",
                        data: yearly_expense_array
                },
                {
                label: "Collection",
                        fillColor: "rgba(102, 170, 24, 0.6)",
                        strokeColor: "rgba(102, 170, 24, 0.6)",
                        pointColor: "rgba(102, 170, 24, 0.9)",
                        pointStrokeColor: "rgba(102, 170, 24, 0.6)",
                        pointHighlightFill: "#fff",
                        pointHighlightStroke: "rgba(60,141,188,1)",
                        data: yearly_collection_array
                }
                ]
        };
        lineChart.Line(areaChartData_expense_Income, lineChartOptions);
        }

        var current_month_days = <?php echo json_encode($current_month_days) ?>;
        var days_collection = <?php echo json_encode($days_collection) ?>;
        var days_expense = <?php echo json_encode($days_expense) ?>;
        var areaChartData_classAttendence = {
        labels: current_month_days,
                datasets: [
                {
                label: "Electronics",
                        fillColor: "rgba(102, 170, 24, 0.6)",
                        strokeColor: "rgba(102, 170, 24, 0.6)",
                        pointColor: "rgba(102, 170, 24, 0.6)",
                        pointStrokeColor: "#c1c7d1",
                        pointHighlightFill: "#fff",
                        pointHighlightStroke: "rgba(220,220,220,1)",
                        data: days_collection
                },
                {
                label: "Digital Goods",
                        fillColor: "rgba(233, 30, 99, 0.9)",
                        strokeColor: "rgba(233, 30, 99, 0.9)",
                        pointColor: "rgba(233, 30, 99, 0.9)",
                        pointStrokeColor: "rgba(233, 30, 99, 0.9)",
                        pointHighlightFill: "rgba(233, 30, 99, 0.9)",
                        pointHighlightStroke: "rgba(60,141,188,1)",
                        data: days_expense
                }
                ]
        };
        if (bar_chart) {
        var barChartCanvas = $("#barChart").get(0).getContext("2d");
        var barChart = new Chart(barChartCanvas);
        var barChartData = areaChartData_classAttendence;
        barChartData.datasets[1].fillColor = "rgba(233, 30, 99, 0.9)";
        barChartData.datasets[1].strokeColor = "rgba(233, 30, 99, 0.9)";
        barChartData.datasets[1].pointColor = "rgba(233, 30, 99, 0.9)";
        var barChartOptions = {
        scaleBeginAtZero: true,
                scaleShowGridLines: true,
                scaleGridLineColor: "rgba(0,0,0,.05)",
                scaleGridLineWidth: 1,
                scaleShowHorizontalLines: false,
                scaleShowVerticalLines: false,
                barShowStroke: true,
                barStrokeWidth: 2,
                barValueSpacing: 5,
                barDatasetSpacing: 1,
                responsive: true,
                maintainAspectRatio: true
        };
        barChartOptions.datasetFill = false;
        barChart.Bar(barChartData, barChartOptions);
        }
        });
    <?php
//}
?>


    $(document).ready(function () {

    $(document).on('click', '.close_notice', function () {
    var data = $(this).data();
    $.ajax({
    type: "POST",
            url: base_url + "admin/notification/read",
            data: {'notice': data.noticeid},
            dataType: "json",
            success: function (data) {
            if (data.status == "fail") {

            errorMsg(data.msg);
            } else {
            successMsg(data.msg);
            }

            }
    });
    });
    });
</script>