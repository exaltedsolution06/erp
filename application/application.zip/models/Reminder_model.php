<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Reminder_model extends MY_Model {

    function __construct() {
        parent::__construct();
        $this->current_session = $this->setting_model->getCurrentSession();
    }

    public function addReminder($data) {
        $this->db->trans_start(); # Starting Transaction
        $this->db->trans_strict(false); # See Note 01. If you wish can remove as well
        //=======================Code Start===========================
        if (isset($data['id'])) {
            $this->db->where('id', $data['id']);
            $this->db->update('template_reminder_letter', $data);
            $message = UPDATE_RECORD_CONSTANT . " On  template reminder letter id " . $data['id'];
            $action = "Update";
            $record_id = $data['id'];
            $this->log($message, $record_id, $action);
            //======================Code End==============================

            $this->db->trans_complete(); # Completing transaction
            /* Optional */

            if ($this->db->trans_status() === false) {
                # Something went wrong.
                $this->db->trans_rollback();
                return false;
            } else {
                //return $return_value;
            }
        } else {
            $this->db->insert('template_reminder_letter', $data);
            $insert_id = $this->db->insert_id();
            $message = INSERT_RECORD_CONSTANT . " On template reminder letter id " . $insert_id;
            $action = "Insert";
            $record_id = $insert_id;
            $this->log($message, $record_id, $action);
            //======================Code End==============================

            $this->db->trans_complete(); # Completing transaction
            /* Optional */

            if ($this->db->trans_status() === false) {
                # Something went wrong.
                $this->db->trans_rollback();
                return false;
            } else {
                //return $return_value;
            }
            return $insert_id;
        }
    }

    public function remindLetterList() {
        $this->db->select('*');
        $this->db->from('template_reminder_letter');
		$this->db->where('session_id', $this->current_session);
        $query = $this->db->get();
        return $query->result();
    }

    public function get($id) {
        $this->db->select('*');
        $this->db->from('template_reminder_letter');
		$this->db->where('session_id', $this->current_session);
        $this->db->where('id', $id);
        $query = $this->db->get();
        return $query->result();
    }

    public function remove($id) {
        $this->db->trans_start(); # Starting Transaction
        $this->db->trans_strict(false); # See Note 01. If you wish can remove as well
        //=======================Code Start===========================
        $this->db->where('id', $id);
		$this->db->where('session_id', $this->current_session);
        $this->db->delete('template_reminder_letter');
        $message = DELETE_RECORD_CONSTANT . " On  template reminder letter id " . $id;
        $action = "Delete";
        $record_id = $id;
        $this->log($message, $record_id, $action);
        //======================Code End==============================
        $this->db->trans_complete(); # Completing transaction
        /* Optional */
        if ($this->db->trans_status() === false) {
            # Something went wrong.
            $this->db->trans_rollback();
            return false;
        } else {
            //return $return_value;
        }
    }

    public function getstudentcertificate() {
        $this->db->select('*');
        $this->db->from('certificates');
		$this->db->where('session_id', $this->current_session);
        $this->db->where('created_for = 2');
        $query = $this->db->get();
        return $query->result();
    }

    public function certifiatebyid($id) {
        $this->db->select('*');
        $this->db->from('certificates');
		$this->db->where('session_id', $this->current_session);
        $this->db->where('id', $id);
        $query = $this->db->get();
        return $query->row();
    }

}

?>