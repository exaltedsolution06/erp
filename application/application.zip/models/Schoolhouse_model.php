<?php

class Schoolhouse_model extends MY_model {

	public function __construct() {
        parent::__construct();
        $this->current_session = $this->setting_model->getCurrentSession();
    }
    public function get($id = null) {

        if (!empty($id)) {
            $query = $this->db->where("id", $id)->where('session_id', $this->current_session)->get("school_houses");

            return $query->row_array();
        } else {

            $query = $this->db->where('session_id', $this->current_session)->get("school_houses");
            return $query->result_array();
        }
    }

    public function add($data) {
        $this->db->trans_start(); # Starting Transaction
        $this->db->trans_strict(false); # See Note 01. If you wish can remove as well
        //=======================Code Start===========================
        if (isset($data["id"])) {
            $this->db->where("id", $data["id"])->update("school_houses", $data);
            $message = UPDATE_RECORD_CONSTANT . " On  school houses id " . $data["id"];
            $action = "Update";
            $record_id = $data["id"];
            $this->log($message, $record_id, $action);
            //======================Code End==============================
            $this->db->trans_complete(); # Completing transaction
            /* Optional */
            if ($this->db->trans_status() === false) {
                # Something went wrong.
                $this->db->trans_rollback();
                return false;
            } else {
                //return $return_value;
            }
        } else {
            $this->db->insert("school_houses", $data);
            $id = $this->db->insert_id();
            $message = INSERT_RECORD_CONSTANT . " On school houses id " . $id;
            $action = "Insert";
            $record_id = $id;
            $this->log($message, $record_id, $action);
            //======================Code End==============================
            $this->db->trans_complete(); # Completing transaction
            /* Optional */
            if ($this->db->trans_status() === false) {
                # Something went wrong.
                $this->db->trans_rollback();
                return false;
            } else {
                //return $return_value;
				return $record_id ;
            }
        }
    }

    public function delete($id) {
        $this->db->trans_start(); # Starting Transaction
        $this->db->trans_strict(false); # See Note 01. If you wish can remove as well
        //=======================Code Start===========================
        $this->db->where("id", $id)->where('session_id', $this->current_session)->delete("school_houses");
        $message = DELETE_RECORD_CONSTANT . " On school houses id " . $id;
        $action = "Delete";
        $record_id = $id;
        $this->log($message, $record_id, $action);
        //======================Code End==============================
        $this->db->trans_complete(); # Completing transaction
        /* Optional */
        if ($this->db->trans_status() === false) {
            # Something went wrong.
            $this->db->trans_rollback();
            return false;
        } else {
            //return $return_value;
        }
    }
	/**
	 * Check if a data already exists.
	 * Optional $id parameter excludes the current record during edit.
	 */
	public function data_exists($data, $id = null)
	{
		$this->db->where('house_name', $data);
		if ($id !== null) {
			$this->db->where('id !=', $id); // ignore the current record
		}
		$query = $this->db->where('session_id', $this->current_session)->get('school_houses');
		return $query->num_rows() > 0;
	}

}

?>