-- Module 4: Income / Expense. Run ONCE (phpMyAdmin > SQL). Safe to re-run (MariaDB IF NOT EXISTS). Additive only.
-- balance_sheets holds both income (balance_type 0) and expense (1); it had NO index except the primary key.
ALTER TABLE `balance_sheets`
  ADD INDEX IF NOT EXISTS `idx_bs_session_type_status_date` (`session_id`, `balance_type`, `status`, `date`),
  ADD INDEX IF NOT EXISTS `idx_bs_student` (`student_id`),
  ADD INDEX IF NOT EXISTS `idx_bs_staff` (`staff_id`),
  ADD INDEX IF NOT EXISTS `idx_bs_head` (`head_id`),
  ADD INDEX IF NOT EXISTS `idx_bs_receipt_no` (`receipt_no`);

-- Add Income student dropdown joins users on user_id + role (also in the Module 1 script; safe to repeat)
ALTER TABLE `users`
  ADD INDEX IF NOT EXISTS `idx_users_user_role` (`user_id`, `role`);
