Module 4 - Income / Expense (filter / load speed)
=================================================
1) Copy the files over your project (same paths).
2) Run database/income_expense_indexes.sql once.

Changed files
- application/models/Income_model.php, application/models/Expense_model.php
    * Date filters (Search Income / Search Expense / Income-Expense report, finance head totals,
      today / month / session totals used on the Dashboard) no longer wrap the column in
      DATE() / date_format(), so the new (session, type, status, date) index can be used.
      Dates are now bound values instead of being concatenated into the SQL string.
    * Income model: new getStudentDropdown().
- application/controllers/admin/Income.php
    * Add Income / Edit Income student dropdown used Student_model->get() (every student with ~13 joins
      and ~90 columns, only id + first name were used). It now uses getStudentDropdown().

Behaviour note: balance_sheets.date is a timestamp. Search Income / Search Expense used "date <= YYYY-MM-DD",
which skipped entries made on the LAST day of the range after 00:00. The range now includes the whole last day,
like the other reports do.

Not changed: the Income / Expense lists on the Add pages still show all rows of the session ("Recent" lists).
The Dashboard income/expense chart still runs one query per month (Admin.php); that belongs to a later
dashboard pass.
