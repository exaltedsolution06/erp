Module 5 - Examinations (filter / load speed)
=============================================
1) Copy the files over your project (same paths).
2) Run database/examinations_indexes.sql once.

New file
- application/helpers/exam_report_cache.php   per-request lookup cache for the exam reports

Changed files
- application/controllers/admin/Examresult.php + application/models/Examresult_model.php
    * Exam Result and Rank Report: subject results of ALL students are loaded in one query
      (new getStudentResultByExamBatch) instead of one query per student.
    * Marksheet printing (getExamResults): each exam is loaded once, not once per student.
- application/views/admin/examresult/tabulationreport.php and percentreport.php
    These pages ran 4-6 queries for every student x subject x exam group x exam (subject groups, subject,
    exams, max marks, result, grade). The data is now loaded in a few queries for all students and looked
    up from memory. Calculations and layout are unchanged.

Not changed: Admit Card, Marksheet and Report Card filter pages (one query already), Online Exam
(next-module candidates).
