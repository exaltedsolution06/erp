-- Module 5: Examinations. Run ONCE (phpMyAdmin > SQL). Safe to re-run (MariaDB IF NOT EXISTS). Additive only.

-- NOTE: exam_group_class_batch_exams has a leftover column exam_group_d (typo) that carries the old index;
-- the column the code actually filters on, exam_group_id, had no index.
ALTER TABLE `exam_group_class_batch_exams`
  ADD INDEX IF NOT EXISTS `idx_egcbe_exam_group_id` (`exam_group_id`);

-- Student lists / result lookups: exam + student
ALTER TABLE `exam_group_class_batch_exam_students`
  ADD INDEX IF NOT EXISTS `idx_egcbes_student_exam` (`student_id`, `exam_group_class_batch_exam_id`),
  ADD INDEX IF NOT EXISTS `idx_egcbes_exam_session` (`exam_group_class_batch_exam_id`, `student_session_id`);

-- Results by student + subject
ALTER TABLE `exam_group_exam_results`
  ADD INDEX IF NOT EXISTS `idx_eger_student_subject` (`exam_group_class_batch_exam_student_id`, `exam_group_class_batch_exam_subject_id`);

-- Subjects of an exam
ALTER TABLE `exam_group_class_batch_exam_subjects`
  ADD INDEX IF NOT EXISTS `idx_egcbes_exam_subject` (`exam_group_class_batch_exams_id`, `subject_id`);

-- Class/section filter used by the exam student search
ALTER TABLE `student_session`
  ADD INDEX IF NOT EXISTS `idx_ss_filter` (`session_id`, `class_id`, `section_id`, `is_active`);
