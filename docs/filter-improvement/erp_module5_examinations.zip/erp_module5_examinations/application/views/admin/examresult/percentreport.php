<?php require_once APPPATH . 'helpers/exam_report_cache.php'; $ec = new Exam_report_cache(get_instance(), (isset($stdResult) && !empty($stdResult)) ? array_map(function ($r) { return $r->student_id; }, $stdResult) : array(), isset($post_exam_group_id) ? $post_exam_group_id : array(), isset($exam_ids) ? $exam_ids : array()); ?>
<style>
.filter-box {
  border: 1px solid #ccc;
  padding: 10px;
  border-radius: 5px;
  max-height: 125px;
  overflow-y: auto;
}
.box-header-ptbnull{
	padding-top:2rem;
}
.form-check-label{
	padding-left:1rem;
}
</style>
<div class="content-wrapper" style="min-height: 946px;">
    <section class="content-header">
        <h1>
            <i class="fa fa-map-o"></i> <?php echo $this->lang->line('examinations'); ?> <small><?php echo $this->lang->line('student_fee1'); ?></small>  </h1>
    </section>
    <!-- Main content -->
    <section class="content">
        <?php $this->load->view('reports/_examinations'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="box removeboxmius">
                    <div class="box-header ptbnull"></div>
                    <div class="box-header with-border">
                        <h3 class="box-title"><i class="fa fa-search"></i> <?php echo $this->lang->line('select_criteria'); ?></h3>
                    </div>
                    <div class="box-body">

                        <form role="form" action="<?php echo site_url('admin/examresult/percentreport') ?>" method="post">

                            <?php echo $this->customlib->getCSRF(); ?>

                            <div class="row">
                                <div class="col-sm-6 col-lg-3 col-md-12">
                                    <div class="form-group">
                                        <label><?php echo $this->lang->line('class'); ?></label><small class="req"> *</small>
                                        <select autofocus="" id="class_id" name="class_id" class="form-control" >
                                            <option value=""><?php echo $this->lang->line('select'); ?></option>
                                            <?php
                                            foreach ($classlist as $class) {
                                                ?>
                                                <option value="<?php echo $class['id'] ?>" <?php
                                                if (set_value('class_id') == $class['id']) {
                                                    echo "selected=selected";
                                                }
                                                ?>><?php echo $class['class'] ?></option>
                                                        <?php
                                                    }
                                                    ?>
                                        </select>
                                        <span class="text-danger"><?php echo form_error('class_id'); ?></span>
										
										
                                        <label for="exampleInputEmail1"><?php echo $this->lang->line('section'); ?></label><small class="req"> *</small>
                                        <select  id="section_id" name="section_id" class="form-control" >
                                            <option value=""><?php echo $this->lang->line('select'); ?></option>
                                        </select>
                                        <span class="text-danger"><?php echo form_error('section_id'); ?></span>
                                    </div>
                                </div>

                                <!--<div class="col-sm-6 col-lg-3 col-md-12">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1"><?php echo $this->lang->line('section'); ?></label><small class="req"> *</small>
                                        <select  id="section_id" name="section_id" class="form-control" >
                                            <option value=""><?php echo $this->lang->line('select'); ?></option>
                                        </select>
                                        <span class="text-danger"><?php echo form_error('section_id'); ?></span>
                                    </div>
                                </div>-->
								<div class="col-sm-6 col-lg-3 col-md-12">
									<div class="form-check">
										<input type="checkbox" class="form-check-input master-check" data-target="exam-group-check" id="selectAllExamGroup">
										<label class="form-check-label" for="selectAllExamGroup"> <?php echo $this->lang->line('exam') . " " . $this->lang->line('group'); ?></label><small class="req text-danger"> *</small>
									</div>
									<div class="filter-box">
										<?php
										$selectedExamGroup = $_POST['exam_group_id'] ?? [];
										foreach ($examgrouplist as $ex_group_key => $ex_group_value) {
										$checked = in_array($ex_group_value->id, $selectedExamGroup) ? 'checked' : '';
										echo "<div class='form-check'>
												<input type='checkbox' class='form-check-input exam-group-check' name='exam_group_id[]' value='{$ex_group_value->id}' id='exam-group{$ex_group_value->id}' $checked>
												<label class='form-check-label' for='exam-group{$ex_group_value->id}'>{$ex_group_value->name}</label>
												</div>";
										}
										?>
									</div>
                                    <span class="text-danger"><?php echo form_error('exam_group_id[]'); ?></span>
								</div>
								<div class="col-sm-6 col-lg-3 col-md-12">
									<div class="form-check">
										<input type="checkbox" class="form-check-input master-exam-check" data-target="exam-check" id="selectAllExam">
										<label class="form-check-label" for="selectAllExam"> <?php echo $this->lang->line('exam'); ?></label><small class="req"> *</small>
									</div>
									<div class="filter-box">
										<div id="exam-list-container">
											<?php 
											if(!empty($exam_list)){
												$selectedExam = $_POST['exam_id'] ?? [];
												foreach ($exam_list as $exam_list_exam){
													$checked_exam = in_array($exam_list_exam->id, $selectedExam) ? 'checked' : '';
											?>
												<div class='form-check'>
													<input type='checkbox' class='form-check-input exam-check' 
														name='exam_id[]' value='<?php echo $exam_list_exam->id; ?>' id='exam<?php echo $exam_list_exam->id; ?>' <?php echo $checked_exam; ?>>
													<label class='form-check-label' for='exam<?php echo $exam_list_exam->id; ?>'>
														<?php echo $exam_list_exam->exam; ?>
													</label>
												</div>
											<?php 	
												}
											}
											?>
										</div>
									</div>
                                    <span class="text-danger"><?php echo form_error('exam_id[]'); ?></span>
								</div>
                                <div class="col-md-1 mb-3">
                                    <div class="form-group">
                                        <button type="submit" name="search" value="search_filter" class="btn btn-primary pull-right btn-sm checkbox-toggle"><i class="fa fa-search"></i> <?php echo $this->lang->line('search'); ?></button>
                                    </div>
                                </div>
                            </div>  
                        </form>

                    </div>

                    <?php
                    if (isset($stdResult)) {
                        ?>
                        <div class="box-header ptbnull"></div>  
                        <div class="box-header ptbnull">
                            <h3 class="box-title titlefix"><i class="fa fa-users"></i> <?php echo $this->lang->line('student'); ?> <?php echo $this->lang->line('list'); ?></h3>

                        </div>
                        <div class="box-body">
                            <div class="table-responsive table-header-sticky">
                                <div class="download_label">Percentage Rank report</div>

                                <?php
                                if (empty($stdResult)) {
								?>
									<!--<h3 class="text-center text-danger py-2">
										No record Found!
									</h3>-->
								<?php
                                } else {
									$student_list_array = array();
									foreach($stdResult as $i=>$stddata){
										$student_array = array();
                                        $student_array['admission_no'] = $stddata->admission_no;
                                        $student_array['exam_roll_no'] = ($stddata->roll_no != 0) ? $stddata->roll_no : "-";
                                        $student_array['student_id'] = $stddata->student_id;
                                        $student_array['name'] = $this->customlib->getFullName($stddata->firstname,$stddata->middlename,$stddata->lastname,$sch_setting->middlename,$sch_setting->lastname);
                                        $student_array['father_name'] = $stddata->father_name;
                                        $student_array['mother_name'] = $stddata->mother_name;
                                        $student_array['class'] = $stddata->class;
                                        $student_array['section'] = $stddata->section;
                                        $student_array['fee_category_id'] = $stddata->fee_category_id;
                                        $student_array['route_id'] = $stddata->route_id;
												
										$array1=[];								
										$finalTotal=0;
										$maxMark=[];
										$minMark=[];
										
										$student_id=$stddata->student_id;
										$student_result = $this->studentsession_model->getStudentClass($stddata->student_id);
										$subject_id_data = $ec->class_subject_ids($student_result['class_id'], $student_result['section_id']);
										
										$max_marks = 0;
									
										for($i=0;$i<count($subject_id_data);$i++){
											$rowdata = $ec->subject_row($subject_id_data[$i]);
											$max_marks1 = 0;
											$total1 = 0;
											$array = [];
											if($rowdata->type_one != 'optional'){
												$min_marks = 0;
												foreach($post_exam_group_id as $post_exam_group){
													$total=0;
													$exam_group_id=$post_exam_group;
													
													$exam_type = $ec->exams_for($exam_group_id, $stddata->student_id);
													
													$max_marks1 = 0;
													$term_array = [];
													foreach($exam_type as $type){
														if(in_array($type->id, $exam_ids)){
															$maxMarks = $ec->max_row($type->id, $rowdata->id);
															array_push($maxMark,$maxMarks->max_marks);
															array_push($minMark,$maxMarks->min_marks);
																		
															$resultData = $ec->result_row($type->id, $rowdata->id, $stddata->student_id);

															$min_marks+=$maxMarks->min_marks;
															$max_marks+=$maxMarks->max_marks;
															$max_marks1+=$maxMarks->max_marks;
														
															// $marks = !empty($resultData) ? ($resultData->attendence == 'absent' ? 'AB' : $resultData->get_marks) : "-";
															array_push($term_array, !empty($resultData) ? $resultData->get_marks : 0);
															
															$total+=$resultData->get_marks;
														}
													}
													$total1+=$total;
													array_push($array,$max_marks1);
													$array = array_merge($array,$term_array);
													array_push($array,$total);

													$grade_array = [ 'type'=>'grade', 'marks'=>$max_marks1 ];
													// array_push($array,$max_marks1);
													array_push($array,$grade_array);
												}
													$max_marks=0;
													$finalTotal+=$total1;
													array_push($array1,$array);
											}
										}
										$student_array['max_marks'] = array_sum($maxMark);
										$student_array['finalTotal'] = $finalTotal;
										
										$totalMaxMarks = array_sum($maxMark);
										$grade = ($totalMaxMarks > 0) ? ($finalTotal * 100 / $totalMaxMarks) : 0;
										
										$student_array['percentage'] = $grade;
										$student_list_array[] = $student_array;
									}
									// Sort
									usort($student_list_array, function ($a, $b) {
										return $b['percentage'] <=> $a['percentage'];
									});

									// Rank
									$rank = 1;
									$prevPercentage = null;
									$skip = 0;

									foreach ($student_list_array as $key => $student) {

										$currentPercentage = round($student['percentage'], 2);

										if ($prevPercentage !== null && $currentPercentage == $prevPercentage) {
											$student_list_array[$key]['rank'] = $rank;
											// $skip++;
										} else {
											$rank += $skip;
											$student_list_array[$key]['rank'] = $rank;
											$skip = 1;
										}

										$prevPercentage = $currentPercentage;
									}
                                }
                                ?>

								 <table cellspacing="0" class="table table-striped table-bordered table-hover example table-fixed-header sticky-col-3" style="width:100% !important">
                                    <thead>
                                        <tr>
                                            <th>S.No</th>
                                            <th><?php echo $this->lang->line('admission_no'); ?></th>

                                            <!--<th><?php echo $this->lang->line('roll_no'); ?></th>-->
                                            <th><?php echo $this->lang->line('student_name'); ?></th>
											<th>Father</th>
											<th>Mother</th>
											<th>Class</th>
											<th>Sec.</th>
											<th>Fee Cat.</th>
											<th>Route</th>
											<th>Exam Group</th>
											<th>Exam</th>
                                            <th>M.M</th>
                                            <th>M.O</th>
                                            <th>Percentage</th>                                            
                                            <th><?php echo $this->lang->line('rank'); ?></th>                                            
                                        </tr>
                                    </thead>
                                    <tbody>
										<?php
										$examGroupNames = [];
										if (!empty($_POST['exam_group_id'])) {
											foreach ($_POST['exam_group_id'] as $gid) {
												$group = $this->examgroup_model->get($gid);
												if ($group) {
													$examGroupNames[] = $group->name;
												}
											}
										}
										
										$examNames = [];
										if (!empty($_POST['exam_id'])) {
											foreach ($_POST['exam_id'] as $eid) {
												$exam = $this->examgroup_model->getExamByID($eid);
												if ($exam) {
													$examNames[] = $exam->exam; // or exam_group_name if needed
												}
											}
										}
										?>
                                        <?php
                                        if (!empty($student_list_array)) {
                                            $rank_count = 1;
                                            foreach ($student_list_array as $student_list_value) {
                                               
                                                ?>
                                                <tr>
                                                    <td><?php echo $rank_count; ?></td>
                                                    <td><?php echo $student_list_value['admission_no']; ?></td>

                                                    <!--<td><?php echo ($student_list_value['roll_no'] != 0) ? $student_list_value['roll_no'] : "-"; ?> </td>-->
                                                    <td>
                                                        <a href="<?php echo base_url(); ?>student/view/<?php echo $student_list_value['student_id']; ?>"><?php echo $student_list_value['name'];
 
                                                         ?>
                                                        </a>
                                                    </td>
													<td><?php echo $student_list_value['father_name']; ?></td>
													<td><?php echo $student_list_value['mother_name']; ?></td>
													<td><?php echo $student_list_value['class']; ?></td>
													<td><?php echo $student_list_value['section']; ?></td>
													<td><?php echo ($ec->fee_group_name($student_list_value['fee_category_id']) !== null) ? $ec->fee_group_name($student_list_value['fee_category_id']) : 'N.A';; ?></td>
													<td><?php echo ($ec->route_heading($student_list_value['route_id']) !== null) ? $ec->route_heading($student_list_value['route_id']) : 'N.A'; ?></td>
													<td><?php echo implode(', ', $examGroupNames); ?></td>
													<td><?php echo implode(', ', $examNames); ?></td>
													<td><?php echo $student_list_value['max_marks']; ?></td>
													<td><?php echo $student_list_value['finalTotal']; ?></td>
													<td><?php echo $student_list_value['percentage']; ?>%</td>
                                                    <td><?php echo $student_list_value['rank']; ?></td>
                                                </tr>
                                        <?php
                                            $rank_count++;
                                            }
                                        }
                                        ?>

                                     </tbody>
                                </table>
                             </div>
                        </div>
                </div>
				<?php
					}
				?>
            </div>
        </div>
    </section>
</div>
<script type="text/javascript">
	$(document).ready(function () {
		$('.select2').select2();
        $.extend($.fn.dataTable.defaults, {
            ordering: false,
            paging: false,
            bSort: false,
            info: false
        });
	});
	var class_id = '<?php echo set_value('class_id') ?>';
	var section_id = '<?php echo set_value('section_id') ?>';
	var session_id = '<?php echo set_value('session_id') ?>';
	getSectionByClass(class_id, section_id);

	$(document).on('change', '#class_id', function (e) {
		$('#section_id').html("");
		var class_id = $(this).val();
		getSectionByClass(class_id, 0);
	});

	function getSectionByClass(class_id, section_id) {

		if (class_id !== "") {
			$('#section_id').html("");
			var base_url = '<?php echo base_url() ?>';
			var div_data = '<option value=""><?php echo $this->lang->line('select'); ?></option>';


			$.ajax({
				type: "GET",
				url: base_url + "sections/getByClass",
				data: {'class_id': class_id},
				dataType: "json",
				beforeSend: function () {
					$('#section_id').addClass('dropdownloading');
				},
				success: function (data) {
					$.each(data, function (i, obj)
					{
						var sel = "";
						if (section_id === obj.section_id) {
							sel = "selected";
						}
						div_data += "<option value=" + obj.section_id + " " + sel + ">" + obj.section + "</option>";
					});
					$('#section_id').append(div_data);
				},
				complete: function () {
					$('#section_id').removeClass('dropdownloading');
				}
			});
		}
	}
</script>
<script>
	$(document).on('change', '.master-exam-check', function () {
		const targetClass = $(this).data('target');

		$('.' + targetClass).prop('checked', this.checked);
	});
	$(document).on('change', '.master-check', function () {
		const targetClass = $(this).data('target');

		$('.' + targetClass).prop('checked', this.checked);

		loadExamList();
	});
  $(document).on('change', '.exam-group-check', function () {
		loadExamList();
	});
	function loadExamList() {
		let selected = [];

		$('.exam-group-check:checked').each(function () {
			selected.push($(this).val());
		});

		$.ajax({
			url: base_url + "admin/examgroup/getExamByExamgroupArray",
			type: "POST",
			data: { exam_group_id: selected },
			success: function (res) {
				$('#exam-list-container').html(res);
			}
		});
	}
</script>