<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Per-request cache for the Tabulation and Percentage exam reports.
 * Those views ran several queries for every student x subject x exam group x exam.
 * The data is now loaded in a few queries for all listed students and looked up from memory.
 * Results are identical to the old per-row queries.
 */
if (!class_exists('Exam_report_cache')) {

    class Exam_report_cache
    {
        private $CI;
        private $student_ids;
        private $group_ids;
        private $exam_ids;
        private $exams_map = null;     // group|student => exam rows
        private $max_map = null;       // exam|subject => row
        private $result_map = null;    // exam|subject|student => row
        private $subjects = null;      // id => row
        private $grades = array();
        private $class_subjects = array();
        private $fg = null;
        private $rh = null;

        public function __construct($CI, $student_ids, $group_ids, $exam_ids)
        {
            $this->CI          = $CI;
            $this->student_ids = array_values(array_unique(array_filter((array) $student_ids, 'strlen')));
            $this->group_ids   = array_values(array_unique((array) $group_ids));
            $this->exam_ids    = array_values(array_unique((array) $exam_ids));
        }

        private function chunks()
        {
            return array_chunk($this->student_ids, 500);
        }

        /** exams of an exam group the student is enrolled in (was: one query per student/group/subject) */
        public function exams_for($group_id, $student_id)
        {
            if ($this->exams_map === null) {
                $this->exams_map = array();
                if (!empty($this->group_ids)) {
                    foreach ($this->chunks() as $chunk) {
                        $rows = $this->CI->db->select('exam_group_class_batch_exams.*, exam_group_class_batch_exam_students.student_id AS __sid', false)
                                ->from('exam_group_class_batch_exams')
                                ->join('exam_group_class_batch_exam_students', 'exam_group_class_batch_exam_students.exam_group_class_batch_exam_id = exam_group_class_batch_exams.id')
                                ->where_in('exam_group_class_batch_exams.exam_group_id', $this->group_ids)
                                ->where_in('exam_group_class_batch_exam_students.student_id', $chunk)
                                ->get()->result();
                        foreach ($rows as $r) {
                            $sid = $r->__sid;
                            unset($r->__sid);
                            $this->exams_map[$r->exam_group_id . '|' . $sid][] = $r;
                        }
                    }
                }
            }
            $k = $group_id . '|' . $student_id;
            if (!isset($this->exams_map[$k])) {
                return array();
            }
            $out = array();
            foreach ($this->exams_map[$k] as $r) {
                $out[] = clone $r;
            }
            return $out;
        }

        /** max/min marks of a subject in an exam, or null */
        public function max_row($exam_id, $subject_id)
        {
            if ($this->max_map === null) {
                $this->max_map = array();
                if (!empty($this->exam_ids)) {
                    $rows = $this->CI->db->select('exam_group_class_batch_exams_id AS __eid, subject_id AS __subj, max_marks, min_marks', false)
                            ->from('exam_group_class_batch_exam_subjects')
                            ->where_in('exam_group_class_batch_exams_id', $this->exam_ids)
                            ->order_by('id')
                            ->get()->result();
                    foreach ($rows as $r) {
                        $k = $r->__eid . '|' . $r->__subj;
                        if (!isset($this->max_map[$k])) {
                            unset($r->__eid, $r->__subj);
                            $this->max_map[$k] = $r;
                        }
                    }
                }
            }
            $k = $exam_id . '|' . $subject_id;
            return isset($this->max_map[$k]) ? clone $this->max_map[$k] : null;
        }

        /** student's result row (+max_marks) for a subject in an exam, or null */
        public function result_row($exam_id, $subject_id, $student_id)
        {
            if ($this->result_map === null) {
                $this->result_map = array();
                if (!empty($this->exam_ids)) {
                    foreach ($this->chunks() as $chunk) {
                        $rows = $this->CI->db->select('exam_group_exam_results.*, exam_group_class_batch_exam_subjects.max_marks, exam_group_class_batch_exam_subjects.exam_group_class_batch_exams_id AS __eid, exam_group_class_batch_exam_subjects.subject_id AS __subj, exam_group_class_batch_exam_students.student_id AS __sid', false)
                                ->from('exam_group_exam_results')
                                ->join('exam_group_class_batch_exam_subjects', 'exam_group_class_batch_exam_subjects.id = exam_group_exam_results.exam_group_class_batch_exam_subject_id')
                                ->join('exam_group_class_batch_exam_students', 'exam_group_class_batch_exam_students.id = exam_group_exam_results.exam_group_class_batch_exam_student_id')
                                ->where_in('exam_group_class_batch_exam_subjects.exam_group_class_batch_exams_id', $this->exam_ids)
                                ->where('exam_group_class_batch_exam_students.exam_group_class_batch_exam_id = exam_group_class_batch_exam_subjects.exam_group_class_batch_exams_id', null, false)
                                ->where_in('exam_group_class_batch_exam_students.student_id', $chunk)
                                ->order_by('exam_group_exam_results.id')
                                ->get()->result();
                        foreach ($rows as $r) {
                            $k = $r->__eid . '|' . $r->__subj . '|' . $r->__sid;
                            if (!isset($this->result_map[$k])) {
                                unset($r->__eid, $r->__subj, $r->__sid);
                                $this->result_map[$k] = $r;
                            }
                        }
                    }
                }
            }
            $k = $exam_id . '|' . $subject_id . '|' . $student_id;
            return isset($this->result_map[$k]) ? clone $this->result_map[$k] : null;
        }

        /** subjects row by id, or null */
        public function subject_row($id)
        {
            if ($this->subjects === null) {
                $this->subjects = array();
                foreach ($this->CI->db->get('subjects')->result() as $r) {
                    $this->subjects[$r->id] = $r;
                }
            }
            return isset($this->subjects[$id]) ? clone $this->subjects[$id] : null;
        }

        /** subject ids of all subject groups of a class/section (same loops the views ran per student) */
        public function class_subject_ids($class_id, $section_id)
        {
            $k = $class_id . '|' . $section_id;
            if (!isset($this->class_subjects[$k])) {
                $ids = array();
                $groups = $this->CI->subjectgroup_model->getGroupByClassandSection($class_id, $section_id);
                foreach ($groups as $sgc_val) {
                    $list = $this->CI->subjectgroup_model->getByID($sgc_val['subject_group_id']);
                    foreach ($list as $slg_val) {
                        foreach ($slg_val->group_subject as $subject) {
                            $ids[] = $subject->subject_id;
                        }
                    }
                }
                $this->class_subjects[$k] = $ids;
            }
            return $this->class_subjects[$k];
        }

        /** grade rows for a percentage (same condition as the old inline query) */
        public function grade_rows($pct)
        {
            $k = (string) $pct;
            if (!isset($this->grades[$k])) {
                $this->grades[$k] = $this->CI->db->query("SELECT * FROM `grades` WHERE mark_from>=" . $this->CI->db->escape($pct) . " and mark_upto<=" . $this->CI->db->escape($pct) . " order by mark_upto asc")->result();
            }
            return $this->grades[$k];
        }

        public function fee_group_name($id)
        {
            if ($this->fg === null) {
                $this->fg = array();
                foreach ($this->CI->db->select('id, name')->get('fee_groups')->result() as $r) {
                    $this->fg[$r->id] = $r->name;
                }
            }
            return isset($this->fg[$id]) ? $this->fg[$id] : null;
        }

        public function route_heading($id)
        {
            if ($this->rh === null) {
                $this->rh = array();
                foreach ($this->CI->db->select('id, fees_heading')->get('route_head')->result() as $r) {
                    $this->rh[$r->id] = $r->fees_heading;
                }
            }
            return isset($this->rh[$id]) ? $this->rh[$id] : null;
        }
    }
}
