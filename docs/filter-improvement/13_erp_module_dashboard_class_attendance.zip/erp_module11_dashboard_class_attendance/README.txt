Module 11 - Dashboard + Class Attendance Report
===============================================
1) Copy the files over your project (same paths). The models include the earlier Attendance / Income / Expense
   changes, so this zip is safe to apply after them.
2) Run database/dashboard_class_attendance_indexes.sql once.

Changed files
- application/controllers/admin/Admin.php (Dashboard)
    * Two queries loaded EVERY income row and EVERY expense row of the session (with descriptions) on each
      dashboard visit and the results were never used (their use was commented out) - removed.
    * The yearly income and expense charts ran 12 + 12 queries (one per month); now 2 grouped queries.
- application/models/Income_model.php, Expense_model.php
    New getIncomeAmountByMonth / getExpenseAmountByMonth (same filters as the per-month functions).
- application/controllers/admin/Stuattendence.php + application/models/Stuattendence_model.php
    Reports > Class Attendance Report: the month is loaded in 2 queries (new searchAttendenceReportMonth)
    instead of one per day, and the per-student totals are one grouped query (new count_attendance_month)
    instead of students x attendance-types queries. count_attendance_obj uses a date range.

Not changed: the Dashboard "fees awaiting" widget (one large query + PHP loop) - it depends on the fee indexes above.
