-- Module 11: Dashboard + Class Attendance Report. Run ONCE (phpMyAdmin > SQL). Safe to re-run (MariaDB IF NOT EXISTS). Additive only.
-- (Several of these also appear in earlier module scripts; repeating them is harmless.)

-- Dashboard income/expense widgets and charts
ALTER TABLE `balance_sheets`
  ADD INDEX IF NOT EXISTS `idx_bs_session_type_status_date` (`session_id`, `balance_type`, `status`, `date`);

-- Dashboard "fees awaiting" overview and fee tables
ALTER TABLE `fee_session_groups`
  ADD INDEX IF NOT EXISTS `idx_fsg_session_group` (`session_id`, `fee_groups_id`);
ALTER TABLE `fee_groups_feetype`
  ADD INDEX IF NOT EXISTS `idx_fgf_group_due` (`fee_groups_id`, `due_date`);
ALTER TABLE `student_fees_master`
  ADD INDEX IF NOT EXISTS `idx_sfm_session_group` (`student_session_id`, `fee_session_group_id`);
ALTER TABLE `student_fees_deposite`
  ADD INDEX IF NOT EXISTS `idx_sfd_master_feetype` (`student_fees_master_id`, `fee_groups_feetype_id`);

-- Dashboard student counts and today's attendance, class attendance report
ALTER TABLE `student_session`
  ADD INDEX IF NOT EXISTS `idx_ss_filter` (`session_id`, `class_id`, `section_id`, `is_active`);
ALTER TABLE `student_attendences`
  ADD INDEX IF NOT EXISTS `idx_sa_session_date` (`student_session_id`, `date`),
  ADD INDEX IF NOT EXISTS `idx_sa_date_type` (`date`, `attendence_type_id`);
