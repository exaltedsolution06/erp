<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Income_model extends My_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->current_session = $this->setting_model->getCurrentSession();
    }

    /**
     * This funtion takes id as a parameter and will fetch the record.
     * If id is not provided, then it will fetch all the records form the table.
     * @param int $id
     * @return mixed
     */
    /**
     * Inclusive day-range filter on a TIMESTAMP/DATETIME column without wrapping the column in
     * DATE()/date_format() (index friendly). 'to' is inclusive of the whole last day.
     * Falls back to the DATE() comparison when the inputs are not valid Y-m-d dates.
     */
    private function _apply_day_range($column, $from_date, $to_date)
    {
        $from = DateTime::createFromFormat('Y-m-d', (string) $from_date);
        $to   = DateTime::createFromFormat('Y-m-d', (string) $to_date);
        if ($from && $to && $from->format('Y-m-d') === $from_date && $to->format('Y-m-d') === $to_date) {
            $this->db->where($column . ' >=', $from_date);
            $this->db->where($column . ' <', $to->modify('+1 day')->format('Y-m-d'));
        } else {
            $this->db->where('DATE(' . $column . ') >=', $from_date);
            $this->db->where('DATE(' . $column . ') <=', $to_date);
        }
    }

    /**
     * Students for the "Add / Edit Income" dropdown (id + first name only).
     * Same students as Student_model::get() without the ~13 joins and 90 columns.
     */
    public function getStudentDropdown()
    {
        $this->db->select('students.id, students.firstname');
        $this->db->from('students');
        $this->db->join('student_session', 'student_session.student_id = students.id');
        $this->db->join('users', 'users.user_id = students.id', 'left');
        $this->db->where('student_session.session_id', $this->current_session);
        $this->db->where('users.role', 'student');
        $this->db->where('student_session.is_active', 'yes');
        $this->db->order_by('students.id', 'desc');
        return $this->db->get()->result_array();
    }

    public function search($text = null, $start_date = null, $end_date = null)
    {
		//echo 'search';die;
        if (!empty($text)) {
            $this->db->select('balance_sheets.* ,income_head.income_category')->from('balance_sheets');
            $this->db->join('income_head', 'income_head.id = balance_sheets.head_id', 'left');
            $this->db->join('students', 'students.id = balance_sheets.student_id', 'left');

            $this->db->like('students.firstname', $text);
			$this->db->where('balance_sheets.session_id', $this->current_session);
			$this->db->where('balance_sheets.status', 0);
			$this->db->where('balance_sheets.balance_type', 0); // for income
            $query = $this->db->get();
            return $query->result_array();
        } else {
            $this->db->select('balance_sheets.* ,income_head.income_category')->from('balance_sheets');
            $this->db->join('income_head', 'income_head.id = balance_sheets.head_id', 'left');
            $this->_apply_day_range('balance_sheets.date', $start_date, $end_date);
			$this->db->where('balance_sheets.session_id', $this->current_session);
			$this->db->where('balance_sheets.status', 0);
			$this->db->where('balance_sheets.balance_type', 0); // for income
            $query = $this->db->get();
            return $query->result_array();
        }
    }

    public function searchincomegroup($start_date = null, $end_date = null, $head_id = null)
    {
        $this->db->select('GROUP_CONCAT(income.id,"@",income.name,"@",income.invoice_no,"@",income.date,"@",income.amount) as income, income_head.income_category,sum(income.amount) as total_amount')->from('income');
        $this->db->join('income_head', 'income.inc_head_id = income_head.id');

        $this->db->where('income.date >=', $start_date);
        $this->db->where('income.date <=', $end_date);
        if ($head_id != null) {
            $this->db->where('income.inc_head_id', $head_id);
        }
        $this->db->group_by('income.inc_head_id');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function getIncomeHeadsData($start_date, $end_date)
    {

        $condition = "balance_sheets.balance_type=0";
        $this->_apply_day_range('balance_sheets.date', $start_date, $end_date);

        $this->db->select('sum(balance_sheets.amount) as total,income_category')->from('balance_sheets');
        $this->db->join('income_head', 'balance_sheets.head_id = income_head.id');
        $this->db->where($condition)->group_by('income_head.id');
        $r = $this->db->get()->result_array();
        return $r;
    }
	
	public function getIncomeHeadsData_bck($start_date, $end_date)
    {

        $condition = "date_format(date,'%Y-%m-%d') between '" . $start_date . "' and '" . $end_date . "'";

        $this->db->select('sum(amount) as total,income_category')->from('income');
        $this->db->join('income_head', 'income.inc_head_id = income_head.id');
        $this->db->where($condition)->group_by('income_head.id');
        $r = $this->db->get()->result_array();
        return $r;
    }

    public function get($id = null)
    {
        $this->db->select('balance_sheets.* ,income_head.income_category')->from('balance_sheets');
       //$this->db->join('income_head', 'balance_sheets.head_id = income_head.id');
        $this->db->join('income_head', 'income_head.id = balance_sheets.head_id', 'left');
		//$this->db->where('income_head.session_id', $this->current_session);
		$this->db->where('balance_sheets.session_id', $this->current_session);
		$this->db->where('balance_sheets.balance_type', 0); // for income
		$this->db->where('balance_sheets.status', 0);
		
        if ($id != null) {
            $this->db->where('balance_sheets.id', $id);
        } else {
            $this->db->order_by('balance_sheets.id', 'DESC');
        }

        $query = $this->db->get();
        if ($id != null) {
            return $query->row_array();
        } else {
            return $query->result_array();
        }
    }
	
	public function get_bck($id = null)
    {
        $this->db->select('income.id,income.date,income.name,income.invoice_no,income.amount,income.documents,income.note,income_head.income_category,income.inc_head_id')->from('income');
        $this->db->join('income_head', 'income.inc_head_id = income_head.id');
		$this->db->where('income_head.session_id', $this->current_session);
		$this->db->where('income.session_id', $this->current_session);
        if ($id != null) {
            $this->db->where('income.id', $id);
        } else {
            $this->db->order_by('income.id', 'DESC');
        }

        $query = $this->db->get();
        if ($id != null) {
            return $query->row_array();
        } else {
            return $query->result_array();
        }
    }

    /**
     * This function will delete the record based on the id
     * @param $id
     */
    public function remove($id)
    {

        $this->db->trans_start(); # Starting Transaction
        $this->db->trans_strict(false); # See Note 01. If you wish can remove as well
        //=======================Code Start===========================
        $this->db->where('id', $id);
        $this->db->delete('balance_sheets');
        
        $message   = DELETE_RECORD_CONSTANT . " On  Income   id " . $id;
        $action    = "Delete";
        $record_id = $id;
        $this->log($message, $record_id, $action);
        //======================Code End==============================

        $this->db->trans_complete(); # Completing transaction
        /* Optional */

        if ($this->db->trans_status() === false) {
            # Something went wrong.
            $this->db->trans_rollback();
            return false;
        } else {

            return $id;
        }
    }

    /**
     * This function will take the post data passed from the controller
     * If id is present, then it will do an update
     * else an insert. One function doing both add and edit.
     * @param $data
     */
    public function add($data)
    {
		$this->db->trans_start(); # Starting Transaction
		$this->db->trans_strict(false); # See Note 01. If you wish can remove as well
			
		/*$this->db->where('session_id', $this->current_session);
		$this->db->where('head_id', $data['inc_head_id']);
		$this->db->where('name', $data['name']);
		$check = $this->db->get('balance_sheets');
		if($check->num_rows() > 0)
		{
			return false;
		}
		else
		{*/
			
			//=======================Code Start===========================
			if (isset($data['id'])) {

				$this->db->where('id', $data['id']);
				$this->db->update('balance_sheets', $data);
				$message   = UPDATE_RECORD_CONSTANT . " On  Income   id " . $data['id'];
				$action    = "Update";
				$record_id = $data['id'];
			} else {
				$this->db->insert('balance_sheets', $data);
				$return_value = $this->db->insert_id();
				$message      = INSERT_RECORD_CONSTANT . " On  Income   id " . $return_value;
				$action       = "Insert";
				$record_id    = $return_value;
			}

			$this->log($message, $record_id, $action);

			//======================Code End==============================

			$this->db->trans_complete(); # Completing transaction
			/* Optional */

			if ($this->db->trans_status() === false) {
				# Something went wrong.
				$this->db->trans_rollback();
				return false;
			} else {

				return $record_id;
			}
		//}
    }

    public function check_Exits_group($data)
    {
        $this->db->select('*');
        $this->db->from('income');
        $this->db->where('session_id', $this->current_session);
        $this->db->where('feetype_id', $data['feetype_id']);
        $this->db->where('class_id', $data['class_id']);
        $this->db->limit(1);
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            return false;
        } else {
            return true;
        }
    }

    public function getTypeByFeecategory($type, $class_id)
    {
        $this->db->select('income.id,income.session_id,income.amount,income.invoice_no,income.documents,income.note,income_head.class,feetype.type')->from('income');
        $this->db->join('income_head', 'income.class_id = income_head.id');
        $this->db->join('feetype', 'income.feetype_id = feetype.id');
        $this->db->where('income.class_id', $class_id);
        $this->db->where('income.feetype_id', $type);
        $this->db->where('income.session_id', $this->current_session);
        $this->db->order_by('income.id');
        $query = $this->db->get();
        return $query->row_array();
    }

    public function getTotalExpenseBydate($date)
    {
        $query = 'SELECT sum(amount) as `amount` FROM `income` where date=' . $this->db->escape($date);
        $query = $this->db->query($query);
        return $query->row();
    }

    public function getTotalExpenseBwdate($date_from, $date_to)
    {
        $query = 'SELECT sum(amount) as `amount` FROM `income` where date between ' . $this->db->escape($date_from) . ' and ' . $this->db->escape($date_to);

        $query = $this->db->query($query);
        return $query->row();
    }
	public function todays_other_collection()
	{
		$today = date('Y-m-d');
		$this->db->select('SUM(amount) as today_other_collection');
		$this->db->from('balance_sheets');
		$this->db->where('balance_type',0);
		$this->db->where('status',0);
		$this->db->where('receipt_no',NULL);
		$this->_apply_day_range('balance_sheets.date', date('Y-m-d'), date('Y-m-d'));
		$this->db->where('session_id',$this->current_session);

		$query = $this->db->get();
		return $query->row()->today_other_collection;
	}
	public function todays_collection()
	{
		$today = date('Y-m-d');
		$this->db->select('SUM(amount) as today_other_collection');
		$this->db->from('balance_sheets');
		$this->db->where('balance_type',0);
		$this->db->where('status',0);
		$this->db->where('receipt_no!=',NULL);
		$this->_apply_day_range('balance_sheets.date', date('Y-m-d'), date('Y-m-d'));
		$this->db->where('session_id',$this->current_session);

		$query = $this->db->get();
		return $query->row()->today_other_collection;
	}
	public function todays_income()
	{
		$this->db->select('SUM(amount) as today_total_income');
		$this->db->from('balance_sheets');
		$this->db->where('balance_type',0);
		$this->db->where('status',0);
		$this->_apply_day_range('balance_sheets.date', date('Y-m-d'), date('Y-m-d'));
		$this->db->where('session_id',$this->current_session);

		$query = $this->db->get();
		return $query->row()->today_total_income;
	}
	public function income_by_session($session_id = '', $from_date = '', $to_date = '')
	{
		$this->db->select("
			SUM(CASE WHEN balance_type = 0 THEN amount ELSE 0 END) AS total_collection,
			SUM(CASE
					WHEN balance_type = 0
					AND receipt_no IS NOT NULL
					AND receipt_no != ''
					THEN amount
					ELSE 0
				END) AS collection
		");

		$this->db->from('balance_sheets');
		$this->db->where('status', 0);

		if (!empty($session_id)) {
			$this->db->where('session_id', $session_id);
		}

		if (!empty($from_date) && !empty($to_date)) {
			$this->_apply_day_range('balance_sheets.date', date('Y-m-d', strtotime($from_date)), date('Y-m-d', strtotime($to_date)));
		}

		$result = $this->db->get()->row();

		if (!$result) {
			$result = new stdClass();
			$result->total_collection = 0;
			$result->collection = 0;
		}

		$result->other_collection = $result->total_collection - $result->collection;

		return $result;
	}
	public function get_income_head()
	{
		$this->db->select('id');
        $this->db->from('income_head');
        $this->db->where('session_id', $this->current_session);
        $this->db->where('income_category', INCOME_HEAD_FEE);
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            return $query->row()->id;
        } else {
            
			$data = array(
				'session_id' => $this->current_session,
				'income_category' => INCOME_HEAD_FEE, // define in config/constants
				'description' => INCOME_HEAD_FEE,
				'is_active' => 'yes',
				'is_deleted' => 'no',
				'created_at' => date('Y-m-d h:i:s'),
			);
			$this->db->insert('income_head', $data);
			$return_value = $this->db->insert_id();
			return $return_value;
        }
		
	}
	public function get_income_head_prev($current_session)
	{
		$this->db->select('id');
        $this->db->from('income_head');
        $this->db->where('session_id', $current_session);
        $this->db->where('income_category', PREVIOUS_CASH);
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            return $query->row()->id;
        } else {
            
			$data = array(
				'session_id' => $current_session,
				'income_category' => PREVIOUS_CASH, // define in config/constants
				'description' => PREVIOUS_CASH,
				'is_active' => 'yes',
				'is_deleted' => 'no',
				'created_at' => date('Y-m-d h:i:s'),
			);
			$this->db->insert('income_head', $data);
			$return_value = $this->db->insert_id();
			return $return_value;
        }
		
	}
	public function getIncomeAmountMonthlySessionWise($start_month, $end_month)
	{
		$condition = "balance_type = 0";
        $this->_apply_day_range('balance_sheets.date', $start_month, $end_month);
		$this->db->select('SUM(amount) as total_amount')->from('balance_sheets');
		$this->db->where('status',0);
        $this->db->where($condition);
        $this->db->where('session_id', $this->current_session);
        //$this->db->order_by('date','ASC');
        $query        = $this->db->get();
        return $query->row()->total_amount;
	}
	/**
	 * Income totals per month for a date range in ONE query: array('Y-m' => total).
	 * Same filter as getIncomeAmountMonthlySessionWise() (income, status 0, current session).
	 */
	public function getIncomeAmountByMonth($start_date, $end_date)
	{
		$this->_apply_day_range('balance_sheets.date', $start_date, $end_date);
		$this->db->select("DATE_FORMAT(balance_sheets.date, '%Y-%m') AS ym, SUM(amount) AS total_amount", false)->from('balance_sheets');
		$this->db->where('status', 0);
		$this->db->where('balance_type = 0');
		$this->db->where('session_id', $this->current_session);
		$this->db->group_by('ym');
		$map = array();
		foreach ($this->db->get()->result() as $row) {
			$map[$row->ym] = $row->total_amount;
		}
		return $map;
	}
	public function get_total_income()
	{
		$this->db->select('SUM(amount) as total_amount')->from('balance_sheets');
		$this->db->where('balance_type', 0);
		$this->db->where('status',0);
		$this->db->where('session_id', $this->current_session);
		$query        = $this->db->get();
		return $query->row()->total_amount;
	}
	public function income_details($res = array())
	{
		$this->db->select('*')->from('balance_sheets');
		$this->db->where('balance_type', $res['balance_type']);
		$this->db->where('status',0);
		$this->db->where('id', $res['id']);
		$this->db->where('session_id', $this->current_session);
		$query = $this->db->get();
		return $query->row_array();
	}

}
