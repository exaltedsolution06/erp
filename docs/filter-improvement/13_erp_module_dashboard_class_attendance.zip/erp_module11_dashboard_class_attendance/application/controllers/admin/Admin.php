<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
} 

class Admin extends Admin_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model("classteacher_model");
        $this->load->model("Staff_model");
        $this->load->library('Enc_lib');
        $this->sch_setting_detail = $this->setting_model->getSetting();
		$this->load->model("Expense_model");
		$this->current_session = $this->setting_model->getCurrentSession();
    }

    public function unauthorized()
    {
        $data = array();
        $this->load->view('layout/header', $data);
        $this->load->view('unauthorized', $data);
        $this->load->view('layout/footer', $data);
    }

    public function dashboard()
    {

        $role            = $this->customlib->getStaffRole();
        $role_id         = json_decode($role)->id;
        $data['role_id'] = $role_id;

        $staffid       = $this->customlib->getStaffID();
        $notifications = $this->notification_model->getUnreadStaffNotification($staffid, $role_id);

        $data['notifications'] = $notifications;
        $input                 = $this->setting_model->getCurrentSessionName();

        list($a, $b)  = explode('-', $input);
        $Current_year = $a;
        if (strlen($b) == 2) {
            $Next_year = substr($a, 0, 2) . $b;
        } else {
            $Next_year = $b;
        }
        $data['mysqlVersion'] = $this->setting_model->getMysqlVersion();
        $data['sqlMode']      = $this->setting_model->getSqlMode();
        //========================== Current Attendence ==========================
        $current_date       = date('Y-m-d');
        $data['title']      = 'Dashboard';
        $Current_start_date = date('01');
        $Current_date       = date('d');
        $Current_month      = date('m');
        $month_collection   = 0;
        $month_expense      = 0;
        $total_students     = 0;
        $discontinue_students     = 0;
        $total_teachers     = 0;
        $ar                 = $this->startmonthandend();
        $year_str_month     = $Current_year . '-' . $ar[0] . '-01';
        $year_end_month     = date("Y-m-t", strtotime($Next_year . '-' . $ar[1] . '-01'));
		
		//-------
		$year_str_month = date('Y-m-01');
		$year_end_month   = date('Y-m-t');
		//echo $year_str_month.' '.$year_end_month;die;
        $getDepositeAmount  = $this->studentfeemaster_model->getDepositAmountBetweenDate($year_str_month, $year_end_month);
		$getExpenseAmount  = $this->Expense_model->getExpenseAmountBetweenDate($year_str_month, $year_end_month);
		//echo "<pre>"; print_r($getExpenseAmount); die;
        //======================Current Month Collection ==============================
        $first_day_this_month     = date('Y-m-01');
		//------------------------------
		$first_day_this_year = date('Y-01-01');
		$last_day_this_year  = date('Y-12-31');
		$first_day_this_week = date('Y-m-d', strtotime('monday this week'));
		$last_day_this_week  = date('Y-m-d', strtotime('sunday this week'));
		//===============================================
        $current_month_collection = $this->studentfeemaster_model->getDepositAmountBetweenDate($first_day_this_month, $current_date);
        $month_collection         = $this->whatever($current_month_collection, $first_day_this_month, $current_date);
        $expense                  = $this->expense_model->getTotalExpenseBwdate($first_day_this_month, $current_date);
        if (!empty($expense)) {
            $month_expense = $month_expense + $expense->amount;
        }
		
		// yearly expenses
		$yearly_expenses = 0;
		$expenseYearly                  = $this->expense_model->getTotalExpenseBwdateYearly($first_day_this_year, $last_day_this_year);
        if (!empty($expenseYearly)) {
            $yearly_expenses = $yearly_expenses + $expenseYearly->amount;
        }
		//echo $yearly_expenses; die;
		$data['yearly_expenses']    = $yearly_expenses;
		
		// weekly expenses
		$weekly_expense = 0;
		$expenseWeekly                  = $this->expense_model->getTotalExpenseBwdateWeekly($first_day_this_week, $last_day_this_week);
        if (!empty($expenseWeekly)) {
            $weekly_expense = $weekly_expense + $expenseWeekly->amount;
        }
		$data['weekly_expense']    = $weekly_expense;
        //----
        $data['month_collection'] = $month_collection;
        $data['month_expense']    = $month_expense;
		
        $data['total_expenses']    = $yearly_expenses+$month_expense+$weekly_expense;
		
		//--- student count-- 
		$total_male_students = 0;
		$total_female_students = 0;
		$tot_male_students = $this->studentsession_model->getTotalMaleStudentBySession();
        if (!empty($tot_male_students)) {
            $total_male_students = $tot_male_students->total_student;
        }
		$data['total_male_students'] = $total_male_students;
		
		$tot_female_students = $this->studentsession_model->getTotalFemaleStudentBySession();
        if (!empty($tot_female_students)) {
            $total_female_students = $tot_female_students->total_student;
        }
		$data['total_female_students'] = $total_female_students;
		$sum_total_student = $total_male_students + $total_female_students;
		$data['total_male_female_student'] = $sum_total_student;
		
		$data['total_male_percent'] = 0;
		$data['total_female_percent'] = 0;
		if($sum_total_student > 0)
		{
			$data['total_male_percent'] = ($total_male_students/$sum_total_student)*100;
			$data['total_female_percent'] = ($total_female_students/$sum_total_student)*100;
		}
		
		// total attandance
		$data['total_present_student'] = 0;
		$data['total_absent_student'] = 0;
		$data['total_present_percent'] = 0;
		$data['total_absent_percent'] = 0;
		
		$tot_present_students = $this->stuattendence_model->getTodayPresentStudents();
		$data['total_present_student'] = $tot_present_students;
		
		$tot_absent_students = $this->stuattendence_model->getTodayAbsentStudents();
		$data['total_absent_student'] = $tot_absent_students;
		$tot_attandence = $tot_present_students + $tot_absent_students;
		if($tot_attandence > 0)
		{
			$data['total_present_percent'] = ($tot_present_students/$sum_total_student) * 100;
			$data['total_absent_percent'] = ($tot_absent_students/$sum_total_student) * 100;
		}
		
		//-- student fee collection --
		//$studentTransportFees = $this->studentfee_model->getTodayStudentTransportFees();
		//$data['studentTransportColls'] = $studentTransportFees;
		$studentAcademicFees = $this->income_model->todays_collection(); // 1
		$data['studentAcademicColls'] = $studentAcademicFees;
		
		$today_total_income  = $this->income_model->todays_income();  // 3
		$todayTotalCollection = $today_total_income;
		$data['todayTotalCollection']  = $todayTotalCollection;
		
		$today_other_collection  = (int)$today_total_income-(int)$studentAcademicFees; // 2
		$data['today_other_collection'] = $today_other_collection;
		
		//$data['studentTransportCollsPercent'] = 0;
		$data['studentAcademicCollsPercent'] = 0;
		$data['studentOtherCollsPercent'] = 0;
		if($todayTotalCollection > 0)
		{
			//$data['studentTransportCollsPercent'] = ($studentTransportFees/$todayTotalCollection)*100;
			$data['studentAcademicCollsPercent'] = ($studentAcademicFees/$todayTotalCollection)*100;
			$data['studentOtherCollsPercent'] = ($today_other_collection/$todayTotalCollection)*100;
		}
		
		//  todays incone and expense 
		$data['today_total_income'] = $today_total_income;
		
		$today_total_expense  = $this->expense_model->todays_expense();
		$data['today_total_expense'] = $today_total_expense;
		
		$total_financial_summary = $today_total_income + $today_total_expense;
		$data['total_financial_summary'] =  $total_financial_summary;
		
		$data['total_income_percent'] = 0;
		$data['total_expense_percent'] = 0;
		$data['net_cash_in_hands'] = 0;
		
		if($total_financial_summary > 0)
		{
			$data['total_income_percent'] = ($today_total_income/$total_financial_summary) *100;
			$data['total_expense_percent'] = ($today_total_expense/$total_financial_summary) *100;
		}
		
		if($today_total_income > $today_total_expense)
		{
			$data['net_cash_in_hands'] = $today_total_income - $today_total_expense;
		}
		else{
			$data['net_cash_in_hands'] = 0;
		}
		
		//--------
        $tot_students = $this->studentsession_model->getTotalStudentBySession();
        if (!empty($tot_students)) {
            $total_students = $tot_students->total_student;
        }
        $tot_discontinue_students = $this->studentsession_model->getTotalDiscontinueStudentBySession();
        if (!empty($tot_discontinue_students)) {
            $discontinue_students = $tot_discontinue_students->total_student;
        }

        $data['total_students'] = $total_students;
        $data['discontinue_students'] = $discontinue_students;

        $tot_roles = $this->role_model->get();

        foreach ($tot_roles as $key => $value) {
			if($value["is_superadmin"] != 1){
				$count_roles[$value["name"]] = $this->role_model->count_roles($value["id"]);
			}else{
				$count_roles[$value["name"]] = $this->role_model->count_superadmin($value["id"]);
			}
        }
        $data["roles"] = $count_roles;

        //======================== get collection by month ==========================
		
		// get the financial month 
		
		$currentMonth = date('n'); // 1-12
		$currentYear  = date('Y');

		if ($currentMonth >= 4) {
			$year_str_month = $currentYear . '-04-01';
			$year_end_month   = ($currentYear + 1) . '-03-31';
		} else {
			$year_str_month = ($currentYear - 1) . '-04-01';
			$year_end_month   = $currentYear . '-03-31';
		}
		
		
		
        $start_month = strtotime($year_str_month);
        $start       = strtotime($year_str_month);
        $end         = strtotime($year_end_month);
        $coll_month  = array();
        $s           = array();
        $total_month = array();
		
		$expense_start_month = $start_month;
		

		// monthly totals for the charts: one grouped query each (was one query per month)
		$__m = $start_month; $__first = date('Y-m-d', $start_month); $__last = $__first;
		while ($__m <= $end) {
			$__last = date('Y-m-t', $__m);
			$__m    = strtotime('+1 month', $__m);
		}
		$income_by_month  = $this->income_model->getIncomeAmountByMonth($__first, $__last);
		$expense_by_month = $this->Expense_model->getExpenseAmountByMonth($__first, $__last);
		
		//echo "<pre>";print_r($getExpenseAmountSessionWise);die;
		   
        while ($start_month <= $end) {
            $total_month[] = date('M', $start_month);
            $month_start   = date('Y-m-d', $start_month);
            $month_end     = date("Y-m-t", $start_month);
			//echo $month_start.' '.$month_end; die;
            $return  = isset($income_by_month[date('Y-m', $start_month)]) ? $income_by_month[date('Y-m', $start_month)] : null;
			
            //$return        = $this->whatevermonths($getDepositeAmountSessionWise, $month_start, $month_end);
            if ($return) {
                $s[] = $return;
            } else {
                $s[] = "0.00";
            }

            $start_month = strtotime("+1 month", $start_month);
        }
		
        //======================== getexpense by month ==============================
        $ex                  = array();
        $start_session_month = strtotime($year_str_month);
        //while ($start_session_month <= $end) {
        while ($expense_start_month <= $end) {

            //$month_start = date('Y-m-d', $start_session_month);
            //$month_end   = date("Y-m-t", $start_session_month);
			
			$month_start   = date('Y-m-d', $expense_start_month);
            $month_end     = date("Y-m-t", $expense_start_month);
			
            //$expense_monthly = $this->expense_model->getTotalExpenseBwdate($month_start, $month_end);
			
			$return  = isset($expense_by_month[date('Y-m', $expense_start_month)]) ? $expense_by_month[date('Y-m', $expense_start_month)] : null;
			
			if ($return) {
                $ex[] = $return;
            } else {
                $ex[] = "0.00";
            }

            $expense_start_month = strtotime("+1 month", $expense_start_month);
        }
		
		//echo "<pre>";print_r($s);die;
       
        $data['yearly_collection'] = $s;
        $data['yearly_expense']    = $ex;
        $data['total_month']       = $total_month;

        //======================= current month collection /expense ===================
		
        // hardcoded '01' for first day
        $startdate       = date('m/01/Y');
        $enddate         = date('m/t/Y');
        $start           = strtotime($startdate);
        $end             = strtotime($enddate);
        $currentdate     = $start;
        $month_days      = array();
        $days_collection = array();
        while ($currentdate <= $end) {
            $cur_date          = date('Y-m-d', $currentdate);
            $end_date          = date('Y-m-d', $end);
            $month_days[]      = date('d', $currentdate);
			//$coll_amt          = $this->whatever($getDepositeAmount, $cur_date, $cur_date);
            $coll_amt          = $this->whateverdays($getDepositeAmount, $cur_date, $end_date);
            $days_collection[] = $coll_amt;
            $currentdate       = strtotime('+1 day', $currentdate);
        }
		//echo "<pre>";print_r($days_collection);die;
        $data['current_month_days'] = $month_days;
        $data['days_collection']    = $days_collection;

        //======================= current month /expense ==============================
        // hardcoded '01' for first day

        $startdate    = date('m/01/Y');
        $enddate      = date('m/t/Y');
        $start        = strtotime($startdate);
        $end          = strtotime($enddate);
        $currentdate  = $start;
        $days_expense = array();
        while ($currentdate <= $end) {
            $cur_date       = date('Y-m-d', $currentdate);
			$end_date          = date('Y-m-d', $end);
            $month_days[]   = date('d', $currentdate);
            $currentdate    = strtotime('+1 day', $currentdate);
			$ct          = $this->whateverExpensebyday($getExpenseAmount, $cur_date, $end_date);
            //$ct             = $this->getExpensebyday($cur_date);
            $days_expense[] = $ct;
        }

        $data['days_expense']        = $days_expense;
        $student_fee_history         = $this->studentfee_model->getTodayStudentFees();
        $data['student_fee_history'] = $student_fee_history;

        $event_colors         = array("#03a9f4", "#c53da9", "#757575", "#8e24aa", "#d81b60", "#7cb342", "#fb8c00", "#fb3b3b");
        $data["event_colors"] = $event_colors;
        $userdata             = $this->customlib->getUserData();
        $data["role"]         = $userdata["user_type"];
        $start_date           = date('Y-m-01');
        $end_date             = date('Y-m-t');
        $student_due_fee      = $this->studentfeemaster_model->getFeesAwaiting($start_date, $end_date);

        $data['fees_awaiting'] = $student_due_fee;

        $total_fess    = 0;
        $total_paid    = 0;
        $total_unpaid  = 0;
        $total_partial = 0;

        if (!empty($data['fees_awaiting'])) {

            foreach ($data['fees_awaiting'] as $awaiting_key => $awaiting_value) {

                $amount_to_be_taken = 0;
                if ($awaiting_value->is_system) {
                    if ($awaiting_value->amount > 0) {
                        $amount_to_be_taken = $awaiting_value->amount;
                    }
                } elseif ($awaiting_value->is_system == 0) {
                    if ($awaiting_value->fee_amount > 0) {
                        $amount_to_be_taken = $awaiting_value->fee_amount;
                    }

                }
                if ($amount_to_be_taken > 0) {
                    $total_fess++;

                    if (is_string($awaiting_value->amount_detail) && is_array(json_decode($awaiting_value->amount_detail, true)) && (json_last_error() == JSON_ERROR_NONE)) {
                        $amount_paid_details = (json_decode($awaiting_value->amount_detail));
                        $amt_                = 0;
                        foreach ($amount_paid_details as $amount_paid_detail_key => $amount_paid_detail_value) {
                            $amt_ = $amt_ + $amount_paid_detail_value->amount;
                        }

                        if (($amt_ + $amount_paid_detail_value->amount_discount) >= $amount_to_be_taken) {
                            $total_paid++;
                        } elseif (($amt_ + $amount_paid_detail_value->amount_discount) < $amount_to_be_taken) {
                            $total_partial++;
                        }
                    } else {
                        $total_unpaid++;
                    }

                }
            }
        }
		
		//echo INCOME_HEAD_FEE; die;
		//bar_chart days_collection yearly_collection
		$start_date = date('Y-m-01');
		$end_date   = date('Y-m-t');
        $data['incomegraph'] = $this->income_model->getIncomeHeadsData($start_date, $end_date);
        $data['expensegraph'] = $this->expense_model->getExpenseHeadData($start_date, $end_date);
        $enquiry       = $this->admin_model->getAllEnquiryCount($start_date, $end_date);
        $total_counter = $total_paid + $total_unpaid + $total_partial;

        $data['fees_overview'] = array(
            'total_unpaid'     => $total_unpaid,
            'unpaid_progress'  => ($total_counter > 0) ? (($total_unpaid * 100) / $total_counter) : 0,
            'total_paid'       => $total_paid,
            'paid_progress'    => ($total_counter > 0) ? (($total_paid * 100) / $total_counter) : 0,
            'total_partial'    => $total_partial,
            'partial_progress' => ($total_counter > 0) ? (($total_partial * 100) / $total_counter) : 0,
        );

        $total_enquiry = $enquiry['total'];

        if ($total_enquiry > 0) {

            $data['enquiry_overview'] = array(
                'won'              => $enquiry['complete'],
                'won_progress'     => ($enquiry['complete'] * 100) / $total_enquiry,
                'active'           => $enquiry['active'],
                'active_progress'  => ($enquiry['active'] * 100) / $total_enquiry,
                'passive'          => $enquiry['passive'],
                'passive_progress' => ($enquiry['passive'] * 100) / $total_enquiry,
                'dead'             => $enquiry['dead'],
                'dead_progress'    => ($enquiry['dead'] * 100) / $total_enquiry,
                'lost'             => $enquiry['lost'],
                'lost_progress'    => ($enquiry['lost'] * 100) / $total_enquiry,
            );

        } else {

            $data['enquiry_overview'] = array(
                'won'              => 0,
                'won_progress'     => 0,
                'active'           => 0,
                'active_progress'  => 0,
                'passive'          => 0,
                'passive_progress' => 0,
                'dead'             => 0,
                'dead_progress'    => 0,
                'lost'             => 0,
                'lost_progress'    => 0,
            );

        }

        $data['total_paid'] = $total_paid;
        $data['total_fees'] = $total_fess;
        if ($total_fess > 0) {
            $data['fessprogressbar'] = ($total_paid * 100) / $total_fess;
        } else {
            $data['fessprogressbar'] = 0;
        }

        $data['total_enquiry']  = $total_enquiry  = $enquiry['total'];
        $data['total_complete'] = $complete_enquiry = $enquiry['complete'];
        if ($total_enquiry > 0) {
            $data['fenquiryprogressbar'] = ($complete_enquiry * 100) / $total_enquiry;
        } else {
            $data['fenquiryprogressbar'] = 0;
        }

        $bookoverview      = $this->book_model->bookoverview($start_date, $end_date);
        $bookduereport     = $this->bookissue_model->dueforreturn($start_date, $end_date);
        $forreturndata     = $this->bookissue_model->forreturn($start_date, $end_date);
        $dueforreturn      = $bookduereport[0]['total'];
        $forreturn         = $forreturndata[0]['total'];
        $total_qty         = $bookoverview[0]['qty'];
        $total_issued      = $bookoverview[0]['total_issue'];
        $availble          = '0';
        $availble_progress = 0;
        $issued_progress   = 0;
        if ($total_qty > 0) {
            $availble          = $total_qty - $total_issued;
            $availble_progress = ($availble * 100) / $total_qty;
            $issued_progress   = ($total_issued * 100) / $total_qty;
        }
        $data['book_overview'] = array(
            'total'             => $total_qty,
            'total_progress'    => 100,
            'availble'          => $availble,
            'availble_progress' => round($availble_progress, 2),
            'total_issued'      => $total_issued,
            'issued_progress'   => round($issued_progress, 2),
            'dueforreturn'      => $dueforreturn,
            'forreturn'         => $forreturn,
        );
		
        $Attendence                   = $this->stuattendence_model->getTodayDayAttendance($total_students);
        $data['attendence_data']      = $Attendence;
        $Staffattendence              = $this->Staff_model->getTodayDayAttendance();
        $data['Staffattendence_data'] = $Staffattendence;
        $getTotalStaff                = $this->Staff_model->getTotalStaff();
        $data['getTotalStaff_data']   = $getTotalStaff;
        if ($getTotalStaff > 0) {$percentTotalStaff_data = ($Staffattendence * 100) / ($getTotalStaff);} else { $percentTotalStaff_data = '0';}
        $data['percentTotalStaff_data'] = $percentTotalStaff_data;
		$data['staff_absent_count']   = $getTotalStaff - $Staffattendence;
		$data['staff_absent_percent'] = $getTotalStaff > 0 ? (($getTotalStaff - $Staffattendence) * 100) / $getTotalStaff : 0;
        $data['sch_setting']            = $this->sch_setting_detail;

        if ($data['sch_setting']->attendence_type == 0) {
            $data['std_graphclass'] = "col-lg-3 col-md-6 col-sm-6";
        } else {
            $data['std_graphclass'] = "col-lg-4 col-md-6 col-sm-6";
        }
		
		//Student previous balance
		$pre_session = $this->session_model->getPreSession($this->current_session);
		if($pre_session->id){
			$student_Array = json_decode($this->findPreviousBalanceFees($pre_session->id, $this->current_session));
			$data['tot_prev_balance'] = format_amount($student_Array->tot_prev_val);
			
			$student_session_ids = implode(',', array_column($student_Array->student_Array, 'student_session_id'));
			
			$this->db->select_sum('amount');
			$this->db->where('status', 1);
			$this->db->where_in('previous_student_session_id', $ids);

			$query = $this->db->get('received_previous_balance');

			$result = $query->row();
			$data['collected_prev_balance'] = format_amount($result->amount);
			$data['remain_prev_balance'] = format_amount($data['tot_prev_balance'] - $result->amount);
			
			$today_total = $this->db
				->select_sum('amount')
				->where('status', 1)
				->where('DATE(created_at)', date('Y-m-d'))
				->where_in(
					'previous_student_session_id',
					explode(',', $student_session_ids)
				)
				->get('received_previous_balance')
				->row()
				->amount;
			$data['today_collected_balance'] = format_amount($today_total);	
		}else{
			$data['tot_prev_balance'] = $data['collected_prev_balance'] = $data['remain_prev_balance'] = $data['today_collected_balance'] = 0;
		}
		// echo '<pre>';print_r($data['today_collected_balance']);exit;
		
		$setting_result = $this->sch_setting_detail;
		// ticket list
		$list_url = CRM_URL . 'api/Ticket/ticket_counter/' . $setting_result->domain_api_key;
		$ticket_result = call_api_get($list_url);
		$data['ticketcounter'] = $ticket_result['data'];
		// Alert list
		$alert_url = CRM_URL . 'api/Alert/get_alert/' . $setting_result->domain_api_key;
		$alert_result = call_api_get($alert_url);
		$data['alert_result'] = $alert_result['data'];
		// echo '<pre>';print_r($data['alert_result']);exit;

		// Library overview widget (total library student members, staff members, and books)
		if ($this->rbac->hasPrivilege('library_overview_widgets', 'can_view')) {
			$data['total_library_students'] = $this->db->where('member_type', 'student')
				->where('session_id', $this->current_session)
				->count_all_results('libarary_members');

			$data['total_library_staff'] = $this->db->where('member_type', 'teacher')
				->where('session_id', $this->current_session)
				->count_all_results('libarary_members');

			$data['total_library_students_percent'] = $total_students > 0 ? ($data['total_library_students'] / $total_students) * 100 : 0;
			$data['total_library_staff_percent'] = $getTotalStaff > 0 ? ($data['total_library_staff'] / $getTotalStaff) * 100 : 0;

			$books_qty = $this->db->select_sum('qty')
				->where('session_id', $this->current_session)
				->get('books')
				->row();
			$data['total_library_books'] = ($books_qty && $books_qty->qty) ? $books_qty->qty : 0;
		}
		
		// Show the popup only if there's a message AND it hasn't been dismissed this session
		$data['show_alert_popup'] = (
			!empty($data['alert_result']['popup_alert']) &&
			!$this->session->userdata('popup_alert_dismissed')
		);
		// echo '<pre>';print_r($data['show_alert_popup']);exit;
		
		$data['result_data'] = $this->setting_model->getSetting();
		$domain_api_url = CRM_URL .'api/Domain/get_domain_data/'.$data['result_data']->domain_api_key; 
		$api_data = call_api_get($domain_api_url);
		$total_student_current_session = $this->student_model->total_student_current_session();
		$data['max_student_limit'] = (int)$api_data['data']['max_students'] + (int)$api_data['data']['add_on_students'] + (int)$api_data['data']['extra_add_on_students'];
		
        $this->load->view('layout/header', $data);
        $this->load->view('admin/dashboard', $data);
        $this->load->view('layout/footer', $data); 
    }
	// Called via AJAX when the user closes the popup
	public function dismiss_alert_popup()
	{
		$this->session->set_userdata('popup_alert_dismissed', true);
		echo json_encode(['status' => 'success']);
	}
	public function findPreviousBalanceFees($session_id, $current_session) {

        $studentlist = $this->student_model->getPreviousSessionStudentAll($session_id);
		// return json_encode(array('student_Array' => $studentlist, 'is_update' => $is_update, 'tot_prev_val' => $tot_prev_val));
// return $studentlist;
        $is_update = false;
        $student_Array = array();
        if (!empty($studentlist)) {
            $student_comma_seprate = array();

            foreach ($studentlist as $student_list_key => $student_list_value) {
               
                $obj = new stdClass();
                $obj->name = $this->customlib->getFullName($student_list_value->firstname,$student_list_value->middlename,$student_list_value->lastname,$this->sch_setting_detail->middlename,$this->sch_setting_detail->lastname);
                $obj->admission_no = $student_list_value->admission_no;
                $obj->roll_no = $student_list_value->roll_no;
                $obj->father_name = $student_list_value->father_name;
                $obj->student_session_id = $student_list_value->current_student_session_id;
                $obj->student_previous_session_id = $student_list_value->previous_student_session_id;
                // $obj->id = $student_list_value->id;
               
                if (strtotime($student_list_value->admission_date) == 0) {
                    $obj->admission_date = "";
                } else {
                    $obj->admission_date = date($this->customlib->getSchoolDateFormat(), $this->customlib->dateYYYYMMDDtoStrtotime($student_list_value->admission_date));
                }


                $student_Array[] = $obj;
                $student_comma_seprate[] = $student_list_value->current_student_session_id;
            }

            $student_session_array = "(" . implode(",", $student_comma_seprate) . ")";
            $record_exists = $this->studentfeemaster_model->getBalanceMasterRecord($this->balance_group, $student_session_array);

			$tot_prev_val = 0;
            if (!empty($record_exists)) {
                $is_update = true;
                foreach ($student_Array as $stkey => $eachstudent) {

                    $eachstudent->balance = $this->findValueExists($record_exists, $eachstudent->student_session_id);
					$tot_prev_val = $tot_prev_val + $eachstudent->balance;
                }
            } else {
                foreach ($student_Array as $stkey => $eachstudent) {


                    //==========================
                    $student_total_fees = array();
                    if ($eachstudent->student_previous_session_id != "") {

                        $student_total_fees = $this->studentfeemaster_model->getPreviousStudentFees($eachstudent->student_previous_session_id);
                    }

                    if (!empty($student_total_fees)) {
                        $totalfee = 0;
                        $deposit = 0;
                        $discount = 0;
                        $balance = 0;
                        foreach ($student_total_fees as $student_total_fees_key => $student_total_fees_value) {
                            if (!empty($student_total_fees_value->fees)) {
                                foreach ($student_total_fees_value->fees as $each_fee_key => $each_fee_value) {
                                    $totalfee = $totalfee + $each_fee_value->amount;

                                    $amount_detail = json_decode($each_fee_value->amount_detail);
                                    if ($amount_detail != null) {
                                        foreach ($amount_detail as $amount_detail_key => $amount_detail_value) {
                                            $deposit = $deposit + $amount_detail_value->amount;
                                            $discount = $discount + $amount_detail_value->amount_discount;
                                        }
                                    }
                                }
                            }
                        }

                        $eachstudent->balance = $totalfee - ($deposit + $discount);
                        $eachstudent->id = $student_total_fees_value->id;
						$tot_prev_val = $tot_prev_val + $eachstudent->balance;
                    } else {
                        $eachstudent->balance = "0";
                    }
                    //===================
                }
// echo '<pre>'; print_r($student_Array);exit;
            }
        }

        return json_encode(array('student_Array' => $student_Array, 'is_update' => $is_update, 'tot_prev_val' => $tot_prev_val));
    }
	function findValueExists($array, $find) {
        $amount = 0;
        foreach ($array as $x => $x_value) {
            if ($x_value->student_session_id == $find)
                return $x_value->previous_session_balance;
        }
        return $amount;
    }

    public function getUserImage()
    {
        $id     = $this->session->userdata["admin"]["id"];
        $result = $this->staff_model->get($id);
    }

    public function getSession()
    {
        if (!$this->rbac->hasPrivilege('quick_session_change', 'can_view')) {
            access_denied();
        }
        $session             = $this->session_model->getAllSession();
        $data                = array();
        $session_array       = $this->session->has_userdata('session_array');
        $data['sessionData'] = array('session_id' => 0);
        if ($session_array) {
            $data['sessionData'] = $this->session->userdata('session_array');
        } else {
            $setting             = $this->setting_model->get();
            $data['sessionData'] = array('session_id' => $setting[0]['session_id']);
        }
        $data['sessionList'] = $session;
        $this->load->view('admin/partial/_session', $data);
    }

    public function updateSession()
    {
        $session       = $this->input->post('popup_session');
        $session_array = $this->session->has_userdata('session_array');
        if ($session_array) {
            $this->session->unset_userdata('session_array');
        } 
        $session       = $this->session_model->get($session);
        $session_array = array('session_id' => $session['id'], 'session' => $session['session']);
        $this->session->set_userdata('session_array', $session_array);
        echo json_encode(array('status' => 1, 'message' => $this->lang->line('session_changed_successfully')));
    }

    public function updatePurchaseCode()
    {
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|trim|xss_clean');
        $this->form_validation->set_rules('envato_market_purchase_code', 'Purchase Code', 'required|trim|xss_clean');
        if ($this->form_validation->run() == false) {
            $data = array(
                'email'                       => form_error('email'),
                'envato_market_purchase_code' => form_error('envato_market_purchase_code'),
            );
            $array = array('status' => '2', 'error' => $data);

            return $this->output
                ->set_content_type('application/json')
                ->set_status_header(200)
                ->set_output(json_encode($array));
        } else {
            //==================
            $response = $this->auth->app_update();
        }
    }

    public function backup()
    {
        if (!$this->rbac->hasPrivilege('data_backup', 'can_view')) {
            access_denied();
        }
        $this->session->set_userdata('top_menu', 'System Settings');
        $this->session->set_userdata('sub_menu', 'admin/backup');
        $data['title'] = 'Backup History';
        if ($this->input->server('REQUEST_METHOD') == "POST") {
            if ($this->input->post('backup') == "upload") {
                $this->form_validation->set_rules('file', 'Image', 'callback_handle_upload');
                if ($this->form_validation->run() == false) {

                } else {
                    if (isset($_FILES["file"]) && !empty($_FILES['file']['name'])) {
                        $fileInfo  = pathinfo($_FILES["file"]["name"]);
                        $file_name = "db-" . date("Y-m-d_H-i-s") . ".sql";
                        move_uploaded_file($_FILES["file"]["tmp_name"], "./backup/temp_uploaded/" . $file_name);
                        $folder_name  = 'temp_uploaded';
                        $path         = './backup/';
                        $file_restore = $this->load->file($path . $folder_name . '/' . $file_name, true);
                        $file_array   = explode(';', $file_restore);
                        foreach ($file_array as $query) {
                            $trimQuery1 = trim($query);
                            if (!empty($trimQuery1)) {
                                $this->db->query("SET FOREIGN_KEY_CHECKS = 0");
                                $this->db->query($query);
                                $this->db->query("SET FOREIGN_KEY_CHECKS = 1");
                            }
                        }
                        $this->session->set_flashdata('msg', '<div class="alert alert-success text-left">Backup restored successfully!</div>');
                        redirect('admin/admin/backup');
                    }
                }
            }
            if ($this->input->post('backup') == "backup") {
                $this->session->set_flashdata('msg', '<div class="alert alert-success text-left">Backup created successfully!</div>');
                $this->load->helper('download');
                $this->load->dbutil();
                $version  = $this->customlib->getAppVersion();
                // $filename = "db_ver_" . $version . '_' . date("Y-m-d_H-i-s") . ".sql";
                $filename = date("d-m-Y_H-i-s") . ".sql";
                $prefs    = array(
                    'ignore'     => array(),
                    'format'     => 'txt',
                    'filename'   => 'mybackup.sql',
                    'add_drop'   => true,
                    'add_insert' => true,
                    'newline'    => "\n",
                );
                $backup = $this->dbutil->backup($prefs);
                $this->load->helper('file');
                write_file('./backup/database_backup/' . $filename, $backup);
                redirect('admin/admin/backup');
                force_download($filename, $backup);
                $this->session->set_flashdata('feedback', 'Success message for client to see');
                redirect('admin/admin/backup');
            } else if ($this->input->post('backup') == "restore") {
                $folder_name  = 'database_backup';
                $file_name    = $this->input->post('filename');
                $path         = './backup/';
                $filePath     = $path . $folder_name . '/' . $file_name;
                $file_restore = $this->load->file($path . $folder_name . '/' . $file_name, true);
                $db           = (array) get_instance()->db;
                $conn         = mysqli_connect('localhost', $db['username'], $db['password'], $db['database']);

                $sql       = '';
                $error     = false;
                $error_msg = "";
                $result    = mysqli_query($conn, "SET FOREIGN_KEY_CHECKS = 0");

                if (!$result) {
                    $error_msg = "Database failed: " . mysqli_error();
                    $error     = true;
                }
                if (!$error) {
                    if (file_exists($filePath)) {
                        $lines = file($filePath);

                        foreach ($lines as $line) {

                            // Ignoring comments from the SQL script
                            if (substr($line, 0, 2) == '--' || $line == '') {
                                continue;
                            }

                            $sql .= $line;

                            if (substr(trim($line), -1, 1) == ';') {
                                $result = mysqli_query($conn, $sql);
                                if (!$result) {
                                    $error_msg = "Database failed: " . mysqli_error();
                                    $error     = true;
                                    break;
                                }
                                $sql = '';
                            }
                        }
                        if (!$error) {

                            $msg = "Backup restored successfully!";
                        }

                    } // end if file exists

                }

                $result = mysqli_query($conn, "SET FOREIGN_KEY_CHECKS = 1");
                if (!$result) {
                    $error_msg = "Database failed: " . mysqli_error();
                    $error     = true;
                }
                if ($error) {
                    $this->session->set_flashdata('msg', '<div class="alert alert-danger text-left">' . $msg . '</div>');
                } else {
                    $this->session->set_flashdata('msg', '<div class="alert alert-success text-left">' . $msg . '</div>');
                }

                redirect('admin/admin/backup');
            }
        }
        /*$dir    = "./backup/database_backup/";
        $result = array();
        $cdir   = scandir($dir);
        foreach ($cdir as $key => $value) {
            if (!in_array($value, array(".", ".."))) {
                if (is_dir($dir . DIRECTORY_SEPARATOR . $value)) {
                    $result[$value] = dirToArray($dir . DIRECTORY_SEPARATOR . $value);
                } else {
                    $result[] = $value;
                }
            }
        }
        $data['dbfileList']  = $result;*/
		$dir = "./backup/database_backup/";

		$files = array_diff(scandir($dir), array('.', '..'));

		usort($files, function ($a, $b) use ($dir) {
			return filemtime($dir . $b) - filemtime($dir . $a);
		});
		$data['dbfileList'] = $files;

        $setting_result      = $this->setting_model->get();
        $data['settinglist'] = $setting_result;
        $this->load->view('layout/header', $data);
        $this->load->view('admin/backup', $data);
        $this->load->view('layout/footer', $data);
    }

    public function changepass()
    {
        $this->session->set_userdata('top_menu', 'System Settings');
        $this->session->set_userdata('sub_menu', 'changepass/index');
        $data['title'] = 'Change Password';
        $this->form_validation->set_rules('current_pass', 'Current password', 'trim|required|xss_clean');
        $this->form_validation->set_rules('new_pass', 'New password', 'trim|required|xss_clean|matches[confirm_pass]');
        $this->form_validation->set_rules('confirm_pass', 'Confirm password', 'trim|required|xss_clean');
        if ($this->form_validation->run() == false) {
            $sessionData            = $this->session->userdata('loggedIn');
            $this->data['id']       = $sessionData['id'];
            $this->data['username'] = $sessionData['username'];
            $this->load->view('layout/header', $data);
            $this->load->view('admin/change_password', $data);
            $this->load->view('layout/footer', $data);
        } else {
            $sessionData = $this->session->userdata('admin');
            $userdata    = $this->customlib->getUserData();
            $data_array  = array(
                'current_pass' => $this->input->post('current_pass'),
                //'new_pass'     => md5($this->input->post('new_pass')),
                'new_pass'     => $this->enc_lib->passHashEnc($this->input->post('new_pass')),
                'user_id'      => $sessionData['id'],
                'user_email'   => $sessionData['email'],
                'user_name'    => $sessionData['username'],
            );
            $newdata = array(
                'id'       => $sessionData['id'],
                'password' => $this->enc_lib->passHashEnc($this->input->post('new_pass')),
            );
            $check = $this->enc_lib->passHashDyc($this->input->post('current_pass'), $userdata["password"]);
            $query1 = $this->admin_model->checkOldPass($data_array);

            if ($query1) {

                if ($check) {
                    $query2 = $this->admin_model->saveNewPass($newdata);
                    if ($query2) {
                        $data['error_message'] = "<div class='alert alert-success'>Password changed successfully</div>";
                        $this->load->view('layout/header', $data);
                        $this->load->view('admin/change_password', $data);
                        $this->load->view('layout/footer', $data);
                    }
                } else {
                    $data['error_message'] = "<div class='alert alert-danger'>Invalid current password</div>";
                    $this->load->view('layout/header', $data);
                    $this->load->view('admin/change_password', $data);
                    $this->load->view('layout/footer', $data);
                }
            } else {

                $data['error_message'] = "<div class='alert alert-danger'>Invalid current password</div>";
                $this->load->view('layout/header', $data);
                $this->load->view('admin/change_password', $data);
                $this->load->view('layout/footer', $data);
            }
        }
    }

    public function pdf_report()
    {
        $data        = array();
        $html        = $this->load->view('reports/students_detail', $data, true);
        $pdfFilePath = "output_pdf_name.pdf";
        $this->load->library('m_pdf');
        $this->m_pdf->pdf->WriteHTML($html);
        $this->m_pdf->pdf->Output($pdfFilePath, "D");
    }

    public function downloadbackup($file)
    {
        $this->load->helper('download');
        $filepath = "./backup/database_backup/" . $file;
        $data     = file_get_contents($filepath);
        $name     = $file;
        force_download($name, $data);
    }

    public function dropbackup($file)
    {
        if (!$this->rbac->hasPrivilege('data_backup', 'can_delete')) {
            access_denied();
        }
        unlink('./backup/database_backup/' . $file);
        redirect('admin/admin/backup');
    }

    public function search()
    {

        $data['title']           = 'Search';
        $search_text             = $this->input->post('search_text1');
        $data['sch_setting']     = $this->sch_setting_detail;
        $data['search_text']     = trim($this->input->post('search_text1'));
        $userdata                = $this->customlib->getUserData();
        $data['adm_auto_insert'] = $this->sch_setting_detail->adm_auto_insert;
        $carray                  = array();
        $class                   = $this->class_model->get();
        $data['classlist']       = $class;
        $data['fields']          = $this->customfield_model->get_custom_fields('students', 1);
        $userdata                = $this->customlib->getUserData();
        $carray                  = array();

        if (!empty($data["classlist"])) {
            foreach ($data["classlist"] as $ckey => $cvalue) {

                $carray[] = $cvalue["id"];
            }
        }

        $resultlist = $this->student_model->searchFullText($search_text, $carray);

        // Exclude discontinued students from the top search results only
        // (searchFullText() is shared by several other features that still
        // need discontinued students included, so filter here instead of
        // in the model).
        $resultlist = array_values(array_filter($resultlist, function ($row) {
            return $row['is_active'] == 'yes';
        }));

        $data['resultlist'] = $resultlist;
        $this->load->view('layout/header', $data);
        $this->load->view('admin/search', $data);
        $this->load->view('layout/footer', $data);
    }

    public function getCollectionbymonth()
    {
        $result = $this->admin_model->getMonthlyCollection();
        return $result;
    }

    public function getCollectionbyday($date)
    {
        $result = $this->admin_model->getCollectionbyDay($date);
        if ($result[0]['amount'] == "") {
            $return = 0;
        } else {
            $return = $result[0]['amount'];
        }
        return $return;
    }

    public function getExpensebyday($date)
    {
        $result = $this->admin_model->getExpensebyDay($date);
        if ($result[0]['amount'] == "") {
            $return = 0;
        } else {
            $return = $result[0]['amount'];
        }
        return $return;
    }

    public function getExpensebymonth()
    {
        $result = $this->admin_model->getMonthlyExpense();
        return $result;
    }
	
	public function whateverdays($feecollection_array, $start_month_date, $end_month_date)
	{
		$return_amount = 0;
		if (!empty($feecollection_array)) {
			
				$date = $start_month_date;
				foreach ($feecollection_array as $k=>$value) {
					$array_date = date('Y-m-d', strtotime($value['date']));
					if ($array_date == $date) {
						$return_amount += $value['amount'];
					}
				}
		}
		return $return_amount;
	}
	
	public function whateverExpensebyday($feecollection_array, $start_month_date, $end_month_date)
	{
		$return_amount = 0;
		if (!empty($feecollection_array)) {
			
				$date = $start_month_date;
				foreach ($feecollection_array as $k=>$value) {
					$array_date = date('Y-m-d', strtotime($value['date']));
					if ($array_date == $date) {
						$return_amount += $value['amount'];
					}
				}
		}
		return $return_amount;
	}
	
    public function whatever($feecollection_array, $start_month_date, $end_month_date)
    {
        $return_amount = 0;
        $st_date       = strtotime($start_month_date);
        $ed_date       = strtotime($end_month_date);
		
        if (!empty($feecollection_array)) {
            while ($st_date <= $ed_date) {
                $date = date('Y-m-d', $st_date);
                foreach ($feecollection_array as $key => $value) {

                    //if ($value['date'] == $date) {

                        $return_amount =  $value['amount'];
                        //$return_amount = $return_amount + $value['amount'] + $value['amount_fine'];
                    //}
                }
                $st_date = $st_date + 86400;
            }
        } else {

        }

        return $return_amount;
    }

    public function startmonthandend()
    {
        $startmonth = $this->setting_model->getStartMonth();
        if ($startmonth == 1) {
            $endmonth = 12;
        } else {
            $endmonth = $startmonth - 1;
        }
        return array($startmonth, $endmonth);
    }

    public function handle_upload()
    {
        if (isset($_FILES["file"]) && !empty($_FILES['file']['name'])) {
            $allowedExts = array('sql');
            $temp        = explode(".", $_FILES["file"]["name"]);
            $extension   = end($temp);
            if ($_FILES["file"]["error"] > 0) {
                $error .= "Error opening the file<br />";
            }
            if ($_FILES["file"]["type"] != 'application/octet-stream') {

                $this->form_validation->set_message('handle_upload', 'File type not allowed');
                return false;
            }
            if (!in_array($extension, $allowedExts)) {

                $this->form_validation->set_message('handle_upload', 'Extension not allowed');
                return false;
            }
            if ($_FILES["file"]["size"] > 10240000) {

                $this->form_validation->set_message('handle_upload', 'File size shoud be less than 100 kB');
                return false;
            }
            return true;
        } else {
            $this->form_validation->set_message('handle_upload', 'File field is required');
            return false;
        }
    }

    public function generate_key($length = 12)
    {
        $str        = "";
        $characters = array_merge(range('A', 'Z'), range('a', 'z'), range('0', '9'));
        $max        = count($characters) - 1;
        for ($i = 0; $i < $length; $i++) {
            $rand = mt_rand(0, $max);
            $str .= $characters[$rand];
        }
        return $str;
    }

    public function addCronsecretkey($id)
    {
        $key = $this->generate_key(25);
        $data = array('cron_secret_key' => $key);
        $this->setting_model->add_cronsecretkey($data, $id);
        redirect('admin/admin/backup');
    }

    public function updateandappCode()
    {
        $this->form_validation->set_rules('app-email', 'Email', 'required|valid_email|trim|xss_clean');
        $this->form_validation->set_rules('app-envato_market_purchase_code', 'Purchase Code', 'required|trim|xss_clean');

        if ($this->form_validation->run() == false) {
            $data = array(
                'app-email'                       => form_error('app-email'),
                'app-envato_market_purchase_code' => form_error('app-envato_market_purchase_code'),
            );
            $array = array('status' => '2', 'error' => $data);

            return $this->output
                ->set_content_type('application/json')
                ->set_status_header(200)
                ->set_output(json_encode($array));
        } else {
            //==================
            $response = $this->auth->andapp_update();
        }
    }

    public function filetype()
    {
		if (!$this->rbac->hasPrivilege('file_types', 'can_view')) {
            access_denied();
        }
        $data          = array();
        $data['title'] = 'File Type List';
        $this->session->set_userdata('top_menu', 'System Settings');
        $this->session->set_userdata('sub_menu', 'System Settings/filetype');
        $data['filetype'] = $this->filetype_model->get();
        $this->load->view('layout/header', $data);
        $this->load->view('admin/filetype', $data);
        $this->load->view('layout/footer', $data);
    }
	public function captcha()
    {
    
        $data          = array();
        $data['title'] = 'File Type List';
        $this->session->set_userdata('top_menu', 'System Settings');
        $this->session->set_userdata('sub_menu', 'System Settings/captcha');
        $data['captcha'] = $this->filetype_model->get();
        $this->load->view('layout/header', $data);
        $this->load->view('admin/captcha', $data);
        $this->load->view('layout/footer', $data);
    }

    public function addfiletype()
    {
        $this->form_validation->set_rules('file_extension', $this->lang->line('allowed_extension'), 'required|trim|xss_clean|callback_validate_extension');
        $this->form_validation->set_rules('image_extension', $this->lang->line('allowed_extension'), 'required|trim|xss_clean|callback_validate_extension');
        $this->form_validation->set_rules('file_mime', $this->lang->line('allowed_mime_type'), 'required|trim|xss_clean|callback_validate_mime');
        $this->form_validation->set_rules('image_mime', $this->lang->line('allowed_mime_type'), 'required|trim|xss_clean|callback_validate_mime');
        $this->form_validation->set_rules('image_size', $this->lang->line('upload_size_in_bytes'), 'required|trim|xss_clean');
        $this->form_validation->set_rules('file_size', $this->lang->line('upload_size_in_bytes'), 'required|trim|xss_clean');

        if ($this->form_validation->run() == false) {
            $data = array(
                'file_extension'  => form_error('file_extension'),
                'file_mime'       => form_error('file_mime'),
                'image_extension' => form_error('image_extension'),
                'image_mime'      => form_error('image_mime'),
                'image_size'      => form_error('image_size'),
                'file_size'       => form_error('file_size'),
            );
            $array = array('status' => 'fail', 'error' => $data);
            echo json_encode($array);
        } else {
            $insert_array = array(
                'file_extension'  => $this->input->post('file_extension'),
                'file_mime'       => $this->input->post('file_mime'),
                'image_extension' => $this->input->post('image_extension'),
                'image_mime'      => $this->input->post('image_mime'),
                'file_size'       => $this->input->post('file_size'),
                'image_size'      => $this->input->post('image_size'),
            );

            $inserted_id = $this->filetype_model->add($insert_array);

            $array = array('status' => 'success', 'error' => '', 'message' => $this->lang->line('success_message'));
            echo json_encode($array);
        }
    }

    public function validate_extension($extension)
    {
        if (preg_match('/^([A-Za-z0-9]+)(,\s[A-Za-z0-9]+)*$/', $extension)) {
            return true;
        } else {
            $this->form_validation->set_message('validate_extension', 'The %s field must be like jpg, jpeg');
            return false;
        }
    }

    public function validate_mime($mime)
    {
        if (preg_match('/^([A-Za-z0-9-.+\/]+)(,\s[A-Za-z0-9-.+\/]+)*$/', $mime)) {
            return true;
        } else {
            $this->form_validation->set_message('validate_mime', 'The %s field must be like audio/mp4, video/mp4');
            return false;
        }
    }

      public function updateaddon()
    {
        $this->form_validation->set_rules('app-email', 'Email', 'required|valid_email|trim|xss_clean');
        $this->form_validation->set_rules('app-envato_market_purchase_code', 'Purchase Code', 'required|trim|xss_clean');

        if ($this->form_validation->run() == false) {

            $data = array(
                'app-email'                       => form_error('app-email'),
                'app-envato_market_purchase_code' => form_error('app-envato_market_purchase_code'),
            );
            
            $array = array('status' => '2', 'error' => $data);

            return $this->output
                ->set_content_type('application/json')
                ->set_status_header(200)
                ->set_output(json_encode($array));
        } else {
            //==================
            $response = $this->auth->addon_update();
        }
    }

}
