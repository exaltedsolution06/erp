Module 7 - Human Resource (filter / load speed)
===============================================
1) Copy the files over your project (same paths).
2) Run database/human_resource_indexes.sql once.

Changed files
- application/controllers/admin/Staffattendance.php + application/models/Staffattendancemodel.php
    * Staff Attendance Report (Reports): the whole month for all staff is loaded in 2 queries
      (new searchAttendanceReportMonth) instead of one query per day, and the per-staff attendance
      totals use ONE grouped query instead of staff x attendance-types queries.
      The role name is now escaped (it was concatenated into the SQL).
- application/models/Payroll_model.php + application/models/Staff_model.php
    * Monthly attendance and leave counts use date ranges instead of month(date)/year(date), so the
      new (staff_id, date) index is used. Used by Payroll, Payslip and the staff profile.
    * New Payroll_model::count_attendance_month (grouped monthly counts).
- application/controllers/admin/Staff.php
    * Staff Search / Disabled Staff: the full staff list is no longer loaded and then thrown away
      when a search is submitted.

Not changed: Approve Leave / Leave Request lists and the Staff ID card pages (small, one query each).
