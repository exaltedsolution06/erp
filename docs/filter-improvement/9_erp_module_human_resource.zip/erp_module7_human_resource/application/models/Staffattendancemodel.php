<?php

class Staffattendancemodel extends MY_Model {

    public function __construct() {
        parent::__construct();
        $this->current_session = $this->setting_model->getCurrentSession();
        $this->current_date = $this->setting_model->getDateYmd();
    }

    public function get($id = null) {
        $this->db->select()->join("staff", "staff.id = staff_attendance.staff_id")->from('staff_attendance');
        $this->db->where("staff.is_active", 1);
		$this->db->where('staff_attendance.session_id', $this->current_session);
        if ($id != null) {
            $this->db->where('staff_attendance.id', $id);
        } else {
            $this->db->order_by('staff_attendance.id');
        }
        $query = $this->db->get();
        if ($id != null) {
            return $query->row_array();
        } else {
            return $query->result_array();
        }
    }

    public function getUserType() {

        $query = $this->db->query("select distinct user_type from staff where is_active = 1");

        return $query->result_array();
    }

    public function searchAttendenceUserType($user_type, $date) {

        if ($user_type == "select") {

            $query = $this->db->query("select staff_attendance.id, staff_attendance.staff_attendance_type_id,staff_attendance.remark,staff.name,staff.surname,staff.employee_id,staff.contact_no,staff.email,roles.name as user_type,IFNULL(staff_attendance.date, 'xxx') as date,staff.id as staff_id from staff left join staff_roles on staff_roles.staff_id = staff.id left join roles on staff_roles.role_id = roles.id left join staff_attendance on (staff.id = staff_attendance.staff_id) and staff_attendance.date = " . $this->db->escape($date) . " and staff_attendance.session_id = " . $this->current_session." where staff.is_active = 1");
        } else {

            $query = $this->db->query("select staff_attendance.staff_attendance_type_id,staff_attendance.remark,staff.name,staff.surname,staff.employee_id,staff.contact_no,staff.email,roles.name as user_type,IFNULL(staff_attendance.date, 'xxx') as date, IFNULL(staff_attendance.id, 0) as id, staff.id as staff_id from staff left join staff_roles on (staff.id = staff_roles.staff_id) left join roles on (roles.id = staff_roles.role_id) left join staff_attendance on (staff.id = staff_attendance.staff_id) and staff_attendance.date = " . $this->db->escape($date) . " and staff_attendance.session_id = " . $this->current_session." where roles.name = " . $this->db->escape($user_type) . " and staff.is_active = 1");
        }
        return $query->result_array();
    }

    public function add($data) {
        $this->db->trans_start(); # Starting Transaction
        $this->db->trans_strict(false); # See Note 01. If you wish can remove as well
        //=======================Code Start===========================
        if (isset($data['id'])) {
            $this->db->where('id', $data['id']);
            $this->db->update('staff_attendance', $data);
            $message = UPDATE_RECORD_CONSTANT . " On staff attendance id " . $data['id'];
            $action = "Update";
            $record_id = $data['id'];
            $this->log($message, $record_id, $action);
        } else {
            $this->db->insert('staff_attendance', $data);
            $id = $this->db->insert_id();
            $message = INSERT_RECORD_CONSTANT . " On staff attendance id " . $id;
            $action = "Insert";
            $record_id = $id;
            $this->log($message, $record_id, $action);
        }
        //======================Code End==============================
        $this->db->trans_complete(); # Completing transaction
        /* Optional */
        if ($this->db->trans_status() === false) {
            # Something went wrong.
            $this->db->trans_rollback();
            return false;
        } else {
            //return $return_value;
        }
    }

    public function getStaffAttendanceType() {

        $query = $this->db->select('*')->where("is_active", 'yes')->get("staff_attendance_type");

        return $query->result_array();
    }

    public function searchAttendanceReport($user_type, $date) {

        if ($user_type == "select") {

            $query = $this->db->query("select staff_attendance.staff_attendance_type_id,staff_attendance_type.type as `att_type`,staff_attendance_type.key_value as `key`,staff_attendance.remark,staff.name,staff.surname,staff.employee_id,staff.contact_no,staff.email,roles.name as user_type,IFNULL(staff_attendance.date, 'xxx') as date, IFNULL(staff_attendance.id, 0) as attendence_id, staff.id as id from staff left join staff_attendance on (staff.id = staff_attendance.staff_id) and staff_attendance.date = " . $this->db->escape($date) . " left join staff_attendance_type on staff_attendance_type.id = staff_attendance.staff_attendance_type_id left join staff_roles on staff_roles.staff_id = staff.id left join roles on staff_roles.role_id = roles.id where staff.is_active = 1");
        } else {

            $query = $this->db->query("select staff_attendance.staff_attendance_type_id,staff_attendance_type.type as `att_type`,staff_attendance_type.key_value as `key`,staff_attendance.remark,staff.name,staff.surname,staff.employee_id,staff.contact_no,staff.email,roles.name as user_type,IFNULL(staff_attendance.date, 'xxx') as date, IFNULL(staff_attendance.id, 0) as attendence_id, staff.id as id from staff  left join staff_roles on (staff.id = staff_roles.staff_id) left join roles on (roles.id = staff_roles.role_id) left join staff_attendance on (staff.id = staff_attendance.staff_id) and staff_attendance.date = " . $this->db->escape($date) . " left join staff_attendance_type on staff_attendance_type.id = staff_attendance.staff_attendance_type_id  where roles.name = '" . $user_type . "' and staff.is_active = 1 ");
        }

        return $query->result_array();
    }

    /**
     * Same rows as searchAttendanceReport($user_type, $date) for every date in $dates,
     * using 2 queries instead of one per day. Returns array(date => rows).
     */
    public function searchAttendanceReportMonth($user_type, $dates) {

        $result = array();
        if (empty($dates)) {
            return $result;
        }

        // staff (+ role) once
        $sql = "select staff.name,staff.surname,staff.employee_id,staff.contact_no,staff.email,roles.name as user_type,staff.id as id from staff left join staff_roles on (staff.id = staff_roles.staff_id) left join roles on (roles.id = staff_roles.role_id) where staff.is_active = 1";
        if ($user_type != "select") {
            $sql .= " and roles.name = " . $this->db->escape($user_type);
        }
        $sql .= " order by staff.id";
        $staff_rows = $this->db->query($sql)->result_array();

        $staff_ids = array();
        foreach ($staff_rows as $row) {
            $staff_ids[$row['id']] = $row['id'];
        }

        // attendance of those staff for the whole range, once
        $att = array();
        if (!empty($staff_ids)) {
            $att_rows = $this->db->select('staff_attendance.id as attendence_id, staff_attendance.staff_id, staff_attendance.date, staff_attendance.remark, staff_attendance.staff_attendance_type_id, staff_attendance_type.type as att_type, staff_attendance_type.key_value as `key`', false)
                    ->from('staff_attendance')
                    ->join('staff_attendance_type', 'staff_attendance_type.id = staff_attendance.staff_attendance_type_id', 'left')
                    ->where_in('staff_attendance.staff_id', array_values($staff_ids))
                    ->where_in('staff_attendance.date', $dates)
                    ->order_by('staff_attendance.id')
                    ->get()->result_array();
            foreach ($att_rows as $a) {
                $att[$a['date']][$a['staff_id']][] = $a;
            }
        }

        foreach ($dates as $date) {
            $rows = array();
            foreach ($staff_rows as $b) {
                if (isset($att[$date][$b['id']])) {
                    foreach ($att[$date][$b['id']] as $a) {
                        $rows[] = array_merge($b, array(
                            'staff_attendance_type_id' => $a['staff_attendance_type_id'],
                            'att_type'                 => $a['att_type'],
                            'key'                      => $a['key'],
                            'remark'                   => $a['remark'],
                            'date'                     => $a['date'],
                            'attendence_id'            => $a['attendence_id'],
                        ));
                    }
                } else {
                    $rows[] = array_merge($b, array(
                        'staff_attendance_type_id' => null,
                        'att_type'                 => null,
                        'key'                      => null,
                        'remark'                   => null,
                        'date'                     => 'xxx',
                        'attendence_id'            => 0,
                    ));
                }
            }
            $result[$date] = $rows;
        }
        return $result;
    }

    public function attendanceYearCount() {

        $query = $this->db->select("distinct year(date) as year")->get("staff_attendance");

        return $query->result_array();
    }

    public function searchStaffattendance($staff_id = 8, $date, $active_staff = true) {

        $sql = "select staff_attendance.staff_attendance_type_id,staff_attendance_type.type as `att_type`,staff_attendance_type.key_value as `key`,staff_attendance.remark,staff.name,staff.surname,staff.contact_no,staff.email,roles.name as user_type,IFNULL(staff_attendance.date, 'xxx') as date, IFNULL(staff_attendance.id, 0) as attendence_id, staff.id as id from staff left join staff_attendance on (staff.id = staff_attendance.staff_id) and staff_attendance.date = " . $this->db->escape($date) . " left join staff_roles on staff_roles.staff_id = staff.id left join roles on staff_roles.role_id = roles.id left join staff_attendance_type on staff_attendance_type.id = staff_attendance.staff_attendance_type_id where staff.id = " . $this->db->escape($staff_id);
        if ($active_staff || !isset($active_staff)) {
            $sql .= " and staff.is_active = 1";
        }
        $query = $this->db->query($sql);
        return $query->row_array();
    }
    public function get_staff_attendancebydate($date, $session_id) {
		$sql = "SELECT
                SUM(CASE WHEN sa.staff_attendance_type_id = 1 THEN 1 ELSE 0 END) AS present,
                SUM(CASE WHEN sa.staff_attendance_type_id = 2 THEN 1 ELSE 0 END) AS late,
                SUM(CASE WHEN sa.staff_attendance_type_id = 3 THEN 1 ELSE 0 END) AS absent,
                SUM(CASE WHEN sa.staff_attendance_type_id = 4 THEN 1 ELSE 0 END) AS half_day,
                SUM(CASE WHEN sa.staff_attendance_type_id = 5 THEN 1 ELSE 0 END) AS holiday,
                COUNT(sa.id) AS total
            FROM staff_attendance sa
            INNER JOIN staff s ON s.id = sa.staff_id
            WHERE sa.date = ?
            AND s.session_id = ?";

    return $this->db->query($sql, array($date, $session_id))->row();
    }

}
