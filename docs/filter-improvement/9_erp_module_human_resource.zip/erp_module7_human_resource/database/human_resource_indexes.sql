-- Module 7: Human Resource. Run ONCE (phpMyAdmin > SQL). Safe to re-run (MariaDB IF NOT EXISTS). Additive only.

-- Staff attendance: monthly counts and the attendance report are by staff + date range
ALTER TABLE `staff_attendance`
  ADD INDEX IF NOT EXISTS `idx_staff_att_staff_date` (`staff_id`, `date`, `staff_attendance_type_id`),
  ADD INDEX IF NOT EXISTS `idx_staff_att_date` (`date`);

-- Payroll list (payslip of the month per staff) and payslip allowances
ALTER TABLE `staff_payslip`
  ADD INDEX IF NOT EXISTS `idx_payslip_staff_month_year` (`staff_id`, `month`, `year`);
ALTER TABLE `payslip_allowance`
  ADD INDEX IF NOT EXISTS `idx_payslip_allow_payslip` (`payslip_id`),
  ADD INDEX IF NOT EXISTS `idx_payslip_allow_staff` (`staff_id`);

-- Leave counts per staff / month / status
ALTER TABLE `staff_leave_request`
  ADD INDEX IF NOT EXISTS `idx_leave_req_staff_status_date` (`staff_id`, `status`, `date`);

-- Staff directory filters
ALTER TABLE `staff`
  ADD INDEX IF NOT EXISTS `idx_staff_active_session` (`is_active`, `session_id`),
  ADD INDEX IF NOT EXISTS `idx_staff_employee_id` (`employee_id`),
  ADD INDEX IF NOT EXISTS `idx_staff_user_id` (`user_id`),
  ADD INDEX IF NOT EXISTS `idx_staff_department` (`department`),
  ADD INDEX IF NOT EXISTS `idx_staff_designation` (`designation`);

-- Staff custom fields are joined once per custom field (also in Module 1 script; safe to repeat)
ALTER TABLE `custom_field_values`
  ADD INDEX IF NOT EXISTS `idx_cfv_belong_field` (`belong_table_id`, `custom_field_id`);
