-- Run on the LIVE database (phpMyAdmin > SQL) BEFORE removing anything.
-- 1) Do the candidate tables hold data on the live site? (the demo dump had none)
SELECT table_name, table_rows AS approx_rows, ROUND((data_length+index_length)/1024,1) AS size_kb, update_time
FROM information_schema.tables
WHERE table_schema = DATABASE()
  AND table_name IN ('multi_class_students','template_marksheets_old_bkp','users_authentication','migrations','student_sibling',
                     'income','expenses','student_fees','feemasters','student_fees_deposite');
-- (table_rows is approximate for InnoDB; for an exact count use SELECT COUNT(*) FROM `table`; )

-- 2) SAFE way to "remove": rename, test the site for a few weeks, then drop. Only for tables that are EMPTY above.
--    (Uncomment the ones you want.)
-- RENAME TABLE `multi_class_students`     TO `zz_unused_multi_class_students`;
-- RENAME TABLE `template_marksheets_old_bkp` TO `zz_unused_template_marksheets_old_bkp`;
-- RENAME TABLE `users_authentication`     TO `zz_unused_users_authentication`;
-- RENAME TABLE `student_sibling`          TO `zz_unused_student_sibling`;
-- To undo:  RENAME TABLE `zz_unused_multi_class_students` TO `multi_class_students`;
-- Do NOT rename `migrations` unless you are sure no migration tool is used; it is harmless to keep.
-- Do NOT rename income / expenses / student_fees / feemasters / student_fees_deposite without testing: code still references them.
