# Unused database tables – report

Database: `u731855585_demoerp` (180 tables). Code: all PHP in `application/`, `backend/` and the root (1,258 files).
Method: every table name was searched as a real database reference (CI query-builder calls, SQL `FROM/JOIN/INTO/UPDATE`,
`table.column`), ignoring comments and "Copy"/backup files; then a call graph of the model classes was traced to find
tables that are only touched by model functions nothing ever calls.
**This is a code-based result. The demo dump is almost empty (105 of 180 tables have no rows), so "no rows" does NOT mean unused.**
Check your live database with `check_unused_tables_live.sql` before changing anything.

## 1. Not used by the code (5 tables)
| Table | Why |
|---|---|
| `multi_class_students` | No reference anywhere in the code, not even in comments |
| `template_marksheets_old_bkp` | No reference; it is an old backup copy of `template_marksheets` |
| `users_authentication` | No reference anywhere |
| `student_sibling` | Only `Student_model::add_student_sibling()` mentions it and nothing calls that function (siblings use `students.parent_id`) |
| `migrations` | CodeIgniter's migration table; `migration_enabled = FALSE` and the migrations folder is empty. Harmless; keep unless you are sure |

## 2. Referenced only by a wrong check (2 tables) – a bug as well
| Table | Why |
|---|---|
| `income` | Old table, replaced by `balance_sheets`. Only used by the **Income Head delete check** (`Incomehead.php`, field `inc_head_id`) |
| `expenses` | Same for the **Expense Head delete check** (`Expensehead.php`) |

Because those checks look at the old empty tables, **you can delete an income/expense head that is already used in
`balance_sheets`**. The tables are not needed, but the check should be changed to look at `balance_sheets.head_id`
(I can send that fix as a small zip if you want).

## 3. Legacy, still referenced by old code (3 tables) – verify before touching
`student_fees`, `feemasters`, `student_fees_deposite`: the old fee system. New fee data lives in `student_fees_master`,
`fee_groups`/`fees_plan` and `receipts`. The old tables are still read by some old functions (old dashboard widget,
old fee-master screens), so removing them could cause errors even though they hold no data here.

## 4. Everything else (170 tables) is used by live code
Full list with row counts and reference counts: `tables_usage.csv`.

## What I would do
1. Run `check_unused_tables_live.sql` on the live DB. If section 1 tables are empty, **rename** them (`zz_unused_...`), watch for a few weeks, then drop.
2. Keep `migrations`. Do not touch sections 2 and 3 until the head-delete check is fixed and the old fee screens are retired.
3. Always take a full database backup first.

## Limits of this check
- Table names built dynamically in code (e.g. `'prefix_' . $x`) cannot be detected; I found none for these tables.
- "Used" means referenced by code that is reachable in principle; a screen that exists but is not linked in the menu is still counted as used.
- I could not run the application, so nothing was confirmed by watching the live database queries. For certainty, enable the MariaDB general log for a few days on the live site and see which tables are ever queried.
