-- Module 10: Alumni / Online Exam / Certificates. Run ONCE (phpMyAdmin > SQL). Safe to re-run (MariaDB IF NOT EXISTS). Additive only.

-- Question bank (server-side list and class/section/subject filters)
ALTER TABLE `questions`
  ADD INDEX IF NOT EXISTS `idx_questions_class_section_subject` (`class_id`, `section_id`, `subject_id`),
  ADD INDEX IF NOT EXISTS `idx_questions_staff` (`staff_id`);

-- Online exam: students of an exam and their session
ALTER TABLE `onlineexam_students`
  ADD INDEX IF NOT EXISTS `idx_oes_exam_session` (`onlineexam_id`, `student_session_id`);
ALTER TABLE `onlineexam`
  ADD INDEX IF NOT EXISTS `idx_onlineexam_session_active` (`session_id`, `is_active`);

-- Alumni events
ALTER TABLE `alumni_events`
  ADD INDEX IF NOT EXISTS `idx_alumni_events_session_class` (`session_id`, `class_id`, `is_active`);

-- Certificates / ID cards (status + session filters)
ALTER TABLE `certificates` ADD INDEX IF NOT EXISTS `idx_certificates_session_status` (`session_id`, `status`);
ALTER TABLE `id_card`      ADD INDEX IF NOT EXISTS `idx_idcard_session_status`      (`session_id`, `status`);

-- Class/section student filter used by Generate Certificate / ID card / Alumni search
-- (already in the Module 1 script; safe to repeat)
ALTER TABLE `student_session`
  ADD INDEX IF NOT EXISTS `idx_ss_filter` (`session_id`, `class_id`, `section_id`, `is_active`);
