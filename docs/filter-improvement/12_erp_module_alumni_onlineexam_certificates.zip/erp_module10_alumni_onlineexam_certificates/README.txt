Module 10 - Alumni / Online Exam / Certificates (filter / load speed)
=====================================================================
1) Copy the files over your project (same paths).
2) Run database/alumni_onlineexam_indexes.sql once.

Changed files
- application/controllers/admin/Question.php
    Question Bank page: question_model->getall() was called on every visit with NO limit (every question
    joined with subjects, classes, sections) and the result was never used - the list is loaded by the
    server-side table (getDatatable). Removed. This is the biggest saving in this module.
- application/controllers/admin/Alumni.php
    Alumni list: the alumni table was loaded on the first (empty) page visit although it is only needed to
    mark rows of a search result. It is now loaded only when a search is submitted.

Reviewed, no change needed: Generate Certificate and Generate ID Card (already load all selected students
in one query), Online Admission list (one query), Online Exam list (indexes on the question / student tables exist;
the correlated counts are covered by them).
Class / section student filters for certificates, ID cards and alumni use the Student search that Module 1 sped up
(Module 1 indexes).
