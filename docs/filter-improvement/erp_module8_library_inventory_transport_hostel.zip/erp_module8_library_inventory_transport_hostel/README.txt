Module 8 - Library / Inventory / Transport / Hostel (filter / load speed)
=========================================================================
1) Copy the files over your project (same paths).
2) Run database/library_inventory_transport_hostel_indexes.sql once.

Changed files
- application/models/Bookissue_model.php, Book_model.php, Itemissue_model.php, Itemstock_model.php
    Report date filters (Student Book Issue, Book Due, Book Inventory / Overview, Issue Item report,
    Add Item Stock report) used date_format(column,...) BETWEEN with the dates pasted into the SQL text.
    They now compare the date column directly (all these columns are DATE, so results are identical),
    which lets the new indexes work, and the dates / member type are escaped (SQL injection fix).
- application/controllers/admin/Hostelroom.php
    Student Hostel Details: a query of all hostel students was run on every first visit and the result
    was never shown - removed.

Not changed: Library member list, Book list, Route / Vehicle / Hostel lists (small, one query each).
