-- Module 8: Library / Inventory / Transport / Hostel. Run ONCE (phpMyAdmin > SQL). Safe to re-run (MariaDB IF NOT EXISTS). Additive only.

-- Library
ALTER TABLE `book_issues`
  ADD INDEX IF NOT EXISTS `idx_bookissue_member` (`member_id`),
  ADD INDEX IF NOT EXISTS `idx_bookissue_book_returned` (`book_id`, `is_returned`),
  ADD INDEX IF NOT EXISTS `idx_bookissue_issue_date` (`issue_date`),
  ADD INDEX IF NOT EXISTS `idx_bookissue_due_returned` (`duereturn_date`, `is_returned`);
ALTER TABLE `libarary_members`
  ADD INDEX IF NOT EXISTS `idx_libmember_member_type` (`member_id`, `member_type`),
  ADD INDEX IF NOT EXISTS `idx_libmember_session_type` (`session_id`, `member_type`);
ALTER TABLE `books`
  ADD INDEX IF NOT EXISTS `idx_books_session_postdate` (`session_id`, `postdate`);

-- Inventory
ALTER TABLE `item_issue`
  ADD INDEX IF NOT EXISTS `idx_itemissue_session_date` (`session_id`, `issue_date`);
ALTER TABLE `item_stock`
  ADD INDEX IF NOT EXISTS `idx_itemstock_session_date` (`session_id`, `date`);

-- Transport / Hostel student details
ALTER TABLE `vehicle_routes`
  ADD INDEX IF NOT EXISTS `idx_vehroute_route` (`route_id`),
  ADD INDEX IF NOT EXISTS `idx_vehroute_vehicle` (`vehicle_id`);
ALTER TABLE `hostel_rooms`
  ADD INDEX IF NOT EXISTS `idx_hostelrooms_hostel` (`hostel_id`),
  ADD INDEX IF NOT EXISTS `idx_hostelrooms_type` (`room_type_id`);
ALTER TABLE `students`
  ADD INDEX IF NOT EXISTS `idx_students_hostel_room` (`hostel_room_id`);
ALTER TABLE `student_session`
  ADD INDEX IF NOT EXISTS `idx_ss_filter` (`session_id`, `class_id`, `section_id`, `is_active`);
