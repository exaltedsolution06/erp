-- Module 6: Homework / Lesson Plan / Syllabus. Run ONCE (phpMyAdmin > SQL). Safe to re-run (MariaDB IF NOT EXISTS). Additive only.

-- Homework list / search / evaluation report: class + section + session (+ date order)
ALTER TABLE `homework`
  ADD INDEX IF NOT EXISTS `idx_homework_filter` (`session_id`, `class_id`, `section_id`, `homework_date`),
  ADD INDEX IF NOT EXISTS `idx_homework_created_by` (`created_by`);

-- Evaluation report / assignment counts per homework
ALTER TABLE `homework_evaluation`
  ADD INDEX IF NOT EXISTS `idx_hweval_homework_student` (`homework_id`, `student_id`);
ALTER TABLE `submit_assignment`
  ADD INDEX IF NOT EXISTS `idx_submit_homework_student` (`homework_id`, `student_id`);

-- Lesson plan / syllabus status
ALTER TABLE `topic`
  ADD INDEX IF NOT EXISTS `idx_topic_lesson_session` (`lesson_id`, `session_id`);
ALTER TABLE `lesson`
  ADD INDEX IF NOT EXISTS `idx_lesson_sgs_sgcs_session` (`subject_group_subject_id`, `subject_group_class_sections_id`, `session_id`);

-- Class teacher restrictions (applied on class/section drop-downs for teachers)
ALTER TABLE `class_teacher`
  ADD INDEX IF NOT EXISTS `idx_class_teacher_filter` (`session_id`, `class_id`, `section_id`, `staff_id`);

-- Student count per class/section (homework completion %)
ALTER TABLE `student_session`
  ADD INDEX IF NOT EXISTS `idx_ss_filter` (`session_id`, `class_id`, `section_id`, `is_active`);
