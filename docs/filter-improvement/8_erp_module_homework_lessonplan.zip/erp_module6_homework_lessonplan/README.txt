Module 6 - Homework / Lesson Plan / Syllabus (filter / load speed)
==================================================================
1) Copy the files over your project (same paths).
2) Run database/homework_lessonplan_indexes.sql once.

Changed files
- application/controllers/Homework.php + application/models/Homework_model.php
    * Homework page loaded every homework of every class (with a query per class and section) on each
      visit and then threw the result away - removed.
    * Per homework row it ran an evaluation report query (not shown on the page) and two staff lookups;
      staff names are now looked up once per person and the unused report query is gone.
    * Evaluation Report: students of a class/section are counted once per class/section and counted
      in SQL (COUNT DISTINCT) instead of loading rows.
- application/controllers/admin/Lessonplan.php + application/controllers/admin/Syllabus.php
  + application/models/Lessonplan_model.php
    * Lesson Plan / Syllabus Status / Manage Topic: topics of all lessons in one query
      (new gettopicsByLessonIds) instead of one query per lesson.

Not changed: Lesson plan report and syllabus report in Reports (loops are per subject only), Manage Lesson list.
