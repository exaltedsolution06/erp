Module 9 - Communicate / Front Office / Download Center (filter / load speed)
=============================================================================
1) Copy the files over your project (same paths).
2) Run database/communicate_frontoffice_indexes.sql once.

Changed files
- application/controllers/admin/Enquiry.php + application/models/Enquiry_model.php
    Admission Enquiry list: the latest follow-up of every enquiry is loaded in one query
    (new getLatestFollowUps) instead of one query per enquiry.
- application/controllers/admin/Notification.php
    Notifications list: creator names and role names are looked up once each, not once per notification.
- application/controllers/admin/Mailsms.php + application/models/Messages_model.php
    Send Email / SMS to a group (students, parents): the recipient list used Student_model->get() (every
    student, about 15 joins and 90 columns) twice. It now uses getStudentContacts(): same students,
    only id / email / phone / guardian contact / app keys, loaded once.

Not changed: Visitors, Complaint, Dispatch, Receive, Phone call log and Download Center lists
(plain one-query lists; they benefit from the indexes only).
