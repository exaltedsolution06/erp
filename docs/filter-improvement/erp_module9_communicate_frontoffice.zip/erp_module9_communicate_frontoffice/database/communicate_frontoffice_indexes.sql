-- Module 9: Communicate / Front Office / Download Center. Run ONCE (phpMyAdmin > SQL). Safe to re-run (MariaDB IF NOT EXISTS). Additive only.

-- Admission Enquiry: latest follow-up per enquiry, list filters
ALTER TABLE `follow_up`
  ADD INDEX IF NOT EXISTS `idx_followup_enquiry` (`enquiry_id`);
ALTER TABLE `enquiry`
  ADD INDEX IF NOT EXISTS `idx_enquiry_status_date` (`status`, `date`),
  ADD INDEX IF NOT EXISTS `idx_enquiry_source` (`source`);

-- Visitor book, complaints, postal dispatch / receive, phone call log: date filters
ALTER TABLE `visitors_book`    ADD INDEX IF NOT EXISTS `idx_visitors_date`   (`date`);
ALTER TABLE `complaint`        ADD INDEX IF NOT EXISTS `idx_complaint_date`  (`date`);
ALTER TABLE `dispatch_receive` ADD INDEX IF NOT EXISTS `idx_dispatch_type_date` (`type`, `date`);
ALTER TABLE `general_calls`    ADD INDEX IF NOT EXISTS `idx_generalcalls_date` (`date`);

-- Notice board / notifications and message log
ALTER TABLE `send_notification`
  ADD INDEX IF NOT EXISTS `idx_sendnotif_session_publish` (`session_id`, `publish_date`),
  ADD INDEX IF NOT EXISTS `idx_sendnotif_created` (`created_id`);
ALTER TABLE `messages`         ADD INDEX IF NOT EXISTS `idx_messages_created` (`created_at`);

-- Download Center
ALTER TABLE `contents`
  ADD INDEX IF NOT EXISTS `idx_contents_session_type` (`session_id`, `type`),
  ADD INDEX IF NOT EXISTS `idx_contents_class` (`class_id`, `cls_sec_id`);

-- "Send to group" student contacts join users on user_id + role (also in the Module 1 script)
ALTER TABLE `users`
  ADD INDEX IF NOT EXISTS `idx_users_user_role` (`user_id`, `role`);
ALTER TABLE `student_session`
  ADD INDEX IF NOT EXISTS `idx_ss_filter` (`session_id`, `class_id`, `section_id`, `is_active`);
