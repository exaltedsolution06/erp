-- ERP speed-up: ALL index changes in one script (everything from modules 0-11).
-- Run ONCE in phpMyAdmin > SQL on the live database (take a backup first). MariaDB 10.5+/11.x (IF NOT EXISTS).
-- Additive only: no data is changed. Safe to re-run. Large tables (receipts, student_attendences, balance_sheets) may take a minute.

ALTER TABLE `alumni_events`
  ADD INDEX IF NOT EXISTS `idx_alumni_events_session_class` (`session_id`, `class_id`, `is_active`);

ALTER TABLE `balance_sheets`
  ADD INDEX IF NOT EXISTS `idx_bs_session_type_status_date` (`session_id`, `balance_type`, `status`, `date`),
  ADD INDEX IF NOT EXISTS `idx_bs_student` (`student_id`),
  ADD INDEX IF NOT EXISTS `idx_bs_staff` (`staff_id`),
  ADD INDEX IF NOT EXISTS `idx_bs_head` (`head_id`),
  ADD INDEX IF NOT EXISTS `idx_bs_receipt_no` (`receipt_no`);

ALTER TABLE `book_issues`
  ADD INDEX IF NOT EXISTS `idx_bookissue_member` (`member_id`),
  ADD INDEX IF NOT EXISTS `idx_bookissue_book_returned` (`book_id`, `is_returned`),
  ADD INDEX IF NOT EXISTS `idx_bookissue_issue_date` (`issue_date`),
  ADD INDEX IF NOT EXISTS `idx_bookissue_due_returned` (`duereturn_date`, `is_returned`);

ALTER TABLE `books`
  ADD INDEX IF NOT EXISTS `idx_books_session_postdate` (`session_id`, `postdate`);

ALTER TABLE `certificates`
  ADD INDEX IF NOT EXISTS `idx_certificates_session_status` (`session_id`, `status`);

ALTER TABLE `class_teacher`
  ADD INDEX IF NOT EXISTS `idx_class_teacher_filter` (`session_id`, `class_id`, `section_id`, `staff_id`);

ALTER TABLE `contents`
  ADD INDEX IF NOT EXISTS `idx_contents_session_type` (`session_id`, `type`),
  ADD INDEX IF NOT EXISTS `idx_contents_class` (`class_id`, `cls_sec_id`);

ALTER TABLE `custom_field_values`
  ADD INDEX IF NOT EXISTS `idx_cfv_belong_field` (`belong_table_id`, `custom_field_id`);

ALTER TABLE `deleted_receipts`
  ADD INDEX IF NOT EXISTS `idx_delrec_session_date` (`session_id`, `date_time`),
  ADD INDEX IF NOT EXISTS `idx_delrec_student` (`student_id`),
  ADD INDEX IF NOT EXISTS `idx_delrec_receipt_no` (`receipt_no`);

ALTER TABLE `dispatch_receive`
  ADD INDEX IF NOT EXISTS `idx_dispatch_type_date` (`type`, `date`);

ALTER TABLE `enquiry`
  ADD INDEX IF NOT EXISTS `idx_enquiry_status_date` (`status`, `date`),
  ADD INDEX IF NOT EXISTS `idx_enquiry_source` (`source`);

ALTER TABLE `exam_group_class_batch_exam_students`
  ADD INDEX IF NOT EXISTS `idx_egcbes_student_exam` (`student_id`, `exam_group_class_batch_exam_id`),
  ADD INDEX IF NOT EXISTS `idx_egcbes_exam_session` (`exam_group_class_batch_exam_id`, `student_session_id`);

ALTER TABLE `exam_group_class_batch_exam_subjects`
  ADD INDEX IF NOT EXISTS `idx_egcbes_exam_subject` (`exam_group_class_batch_exams_id`, `subject_id`);

ALTER TABLE `exam_group_class_batch_exams`
  ADD INDEX IF NOT EXISTS `idx_egcbe_exam_group_id` (`exam_group_id`);

ALTER TABLE `exam_group_exam_results`
  ADD INDEX IF NOT EXISTS `idx_eger_student_subject` (`exam_group_class_batch_exam_student_id`, `exam_group_class_batch_exam_subject_id`);

ALTER TABLE `fee_discounts`
  ADD INDEX IF NOT EXISTS `idx_fee_discounts_ss` (`student_session_id`),
  ADD INDEX IF NOT EXISTS `idx_fee_discounts_updated` (`updated_date`);

ALTER TABLE `fee_groups_feetype`
  ADD INDEX IF NOT EXISTS `idx_fgf_group_due` (`fee_groups_id`, `due_date`);

ALTER TABLE `fee_session_groups`
  ADD INDEX IF NOT EXISTS `idx_fsg_session_group` (`session_id`, `fee_groups_id`);

ALTER TABLE `follow_up`
  ADD INDEX IF NOT EXISTS `idx_followup_enquiry` (`enquiry_id`);

ALTER TABLE `general_calls`
  ADD INDEX IF NOT EXISTS `idx_generalcalls_date` (`date`);

ALTER TABLE `homework`
  ADD INDEX IF NOT EXISTS `idx_homework_filter` (`session_id`, `class_id`, `section_id`, `homework_date`),
  ADD INDEX IF NOT EXISTS `idx_homework_created_by` (`created_by`);

ALTER TABLE `homework_evaluation`
  ADD INDEX IF NOT EXISTS `idx_hweval_homework_student` (`homework_id`, `student_id`);

ALTER TABLE `hostel_rooms`
  ADD INDEX IF NOT EXISTS `idx_hostelrooms_hostel` (`hostel_id`),
  ADD INDEX IF NOT EXISTS `idx_hostelrooms_type` (`room_type_id`);

ALTER TABLE `item_issue`
  ADD INDEX IF NOT EXISTS `idx_itemissue_session_date` (`session_id`, `issue_date`);

ALTER TABLE `item_stock`
  ADD INDEX IF NOT EXISTS `idx_itemstock_session_date` (`session_id`, `date`);

ALTER TABLE `lesson`
  ADD INDEX IF NOT EXISTS `idx_lesson_sgs_sgcs_session` (`subject_group_subject_id`, `subject_group_class_sections_id`, `session_id`);

ALTER TABLE `libarary_members`
  ADD INDEX IF NOT EXISTS `idx_libmember_member_type` (`member_id`, `member_type`),
  ADD INDEX IF NOT EXISTS `idx_libmember_session_type` (`session_id`, `member_type`);

ALTER TABLE `messages`
  ADD INDEX IF NOT EXISTS `idx_messages_created` (`created_at`);

ALTER TABLE `onlineexam`
  ADD INDEX IF NOT EXISTS `idx_onlineexam_session_active` (`session_id`, `is_active`);

ALTER TABLE `onlineexam_students`
  ADD INDEX IF NOT EXISTS `idx_oes_exam_session` (`onlineexam_id`, `student_session_id`);

ALTER TABLE `payslip_allowance`
  ADD INDEX IF NOT EXISTS `idx_payslip_allow_payslip` (`payslip_id`),
  ADD INDEX IF NOT EXISTS `idx_payslip_allow_staff` (`staff_id`);

ALTER TABLE `questions`
  ADD INDEX IF NOT EXISTS `idx_questions_class_section_subject` (`class_id`, `section_id`, `subject_id`),
  ADD INDEX IF NOT EXISTS `idx_questions_staff` (`staff_id`);

ALTER TABLE `receipts`
  ADD INDEX IF NOT EXISTS `idx_receipts_session_date` (`session_id`, `date_time`),
  ADD INDEX IF NOT EXISTS `idx_receipts_student` (`student_id`),
  ADD INDEX IF NOT EXISTS `idx_receipts_back_id` (`back_id`),
  ADD INDEX IF NOT EXISTS `idx_receipts_receipt_no` (`receipt_no`),
  ADD INDEX IF NOT EXISTS `idx_receipts_student_head_month` (`student_id`, `fee_head_name`(60), `months`(20)),
  ADD INDEX IF NOT EXISTS `idx_receipts_student_session_created` (`student_id`, `session_id`, `created_at`);

ALTER TABLE `route_head`
  ADD INDEX IF NOT EXISTS `idx_route_head_session` (`session_id`);

ALTER TABLE `route_plan`
  ADD INDEX IF NOT EXISTS `idx_route_plan_group` (`fee_group_id`);

ALTER TABLE `send_notification`
  ADD INDEX IF NOT EXISTS `idx_sendnotif_session_publish` (`session_id`, `publish_date`),
  ADD INDEX IF NOT EXISTS `idx_sendnotif_created` (`created_id`);

ALTER TABLE `staff`
  ADD INDEX IF NOT EXISTS `idx_staff_active_session` (`is_active`, `session_id`),
  ADD INDEX IF NOT EXISTS `idx_staff_employee_id` (`employee_id`),
  ADD INDEX IF NOT EXISTS `idx_staff_user_id` (`user_id`),
  ADD INDEX IF NOT EXISTS `idx_staff_department` (`department`),
  ADD INDEX IF NOT EXISTS `idx_staff_designation` (`designation`);

ALTER TABLE `staff_attendance`
  ADD INDEX IF NOT EXISTS `idx_staff_att_staff_date` (`staff_id`, `date`, `staff_attendance_type_id`),
  ADD INDEX IF NOT EXISTS `idx_staff_att_date` (`date`);

ALTER TABLE `staff_leave_request`
  ADD INDEX IF NOT EXISTS `idx_leave_req_staff_status_date` (`staff_id`, `status`, `date`);

ALTER TABLE `staff_payslip`
  ADD INDEX IF NOT EXISTS `idx_payslip_staff_month_year` (`staff_id`, `month`, `year`);

ALTER TABLE `student_attendences`
  ADD INDEX IF NOT EXISTS `idx_sa_session_date` (`student_session_id`, `date`),
  ADD INDEX IF NOT EXISTS `idx_sa_date_type` (`date`, `attendence_type_id`);

ALTER TABLE `student_doc`
  ADD INDEX IF NOT EXISTS `idx_student_doc_student` (`student_id`);

ALTER TABLE `student_fees_deposite`
  ADD INDEX IF NOT EXISTS `idx_sfd_master_feetype` (`student_fees_master_id`, `fee_groups_feetype_id`);

ALTER TABLE `student_fees_master`
  ADD INDEX IF NOT EXISTS `idx_sfm_session_group` (`student_session_id`, `fee_session_group_id`),
  ADD INDEX IF NOT EXISTS `idx_sfm_group` (`fee_session_group_id`);

ALTER TABLE `student_session`
  ADD INDEX IF NOT EXISTS `idx_ss_filter` (`session_id`, `class_id`, `section_id`, `is_active`),
  ADD INDEX IF NOT EXISTS `idx_ss_student_session` (`student_id`, `session_id`),
  ADD INDEX IF NOT EXISTS `idx_ss_fee_category` (`fee_category_id`),
  ADD INDEX IF NOT EXISTS `idx_ss_house` (`school_house_id`),
  ADD INDEX IF NOT EXISTS `idx_ss_route` (`route_id`);

ALTER TABLE `students`
  ADD INDEX IF NOT EXISTS `idx_students_admission_no` (`admission_no`),
  ADD INDEX IF NOT EXISTS `idx_students_parent_id` (`parent_id`),
  ADD INDEX IF NOT EXISTS `idx_students_hostel_room` (`hostel_room_id`);

ALTER TABLE `submit_assignment`
  ADD INDEX IF NOT EXISTS `idx_submit_homework_student` (`homework_id`, `student_id`);

ALTER TABLE `topic`
  ADD INDEX IF NOT EXISTS `idx_topic_lesson_session` (`lesson_id`, `session_id`);

ALTER TABLE `users`
  ADD INDEX IF NOT EXISTS `idx_users_user_role` (`user_id`, `role`);

ALTER TABLE `vehicle_routes`
  ADD INDEX IF NOT EXISTS `idx_vehroute_route` (`route_id`),
  ADD INDEX IF NOT EXISTS `idx_vehroute_vehicle` (`vehicle_id`);
