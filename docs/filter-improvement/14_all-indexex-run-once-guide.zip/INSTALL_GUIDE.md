# ERP speed-up – install guide

**Always back up the files and the database first, and try everything on a copy of the site.**
I could not run PHP/MySQL here, so nothing has been executed against your real data.
All changed PHP files were checked for matching brackets/tokens against your originals, and every index
was checked against the table/column names in your SQL dump.

## 1. Database (once)
Run `ALL_indexes_run_once.sql` in phpMyAdmin > SQL. (It contains every index from every module; you do not
need to run the per-module `database/*.sql` files if you do this.)

## 2. Code – copy over your project (same paths)
Zips are independent; where two zips contain the same file, the later module's copy already includes the earlier changes,
so you can apply them in any order, but if you apply several, apply them in this order and overwrite:

| Order | Zip | Area |
|---|---|---|
| 1 | erp_core_update.zip | All pages (cached settings / user / permissions) |
| 2 | erp_attendance_update.zip | Student Attendance |
| 3 | erp_module1_student_information.zip | Student Information |
| 4 | erp_module2_fees_collection.zip | Fees Collection |
| 5 | erp_module3_reports.zip | Reports (new helper `report_cache.php`) |
| 6 | erp_module4_income_expense.zip | Income / Expense |
| 7 | erp_module5_examinations.zip | Examinations (new helper `exam_report_cache.php`) |
| 8 | erp_module6_homework_lessonplan.zip | Homework / Lesson Plan / Syllabus |
| 9 | erp_module7_human_resource.zip | Human Resource |
| 10 | erp_module8_library_inventory_transport_hostel.zip | Library / Inventory / Transport / Hostel |
| 11 | erp_module9_communicate_frontoffice.zip | Communicate / Front Office |
| 12 | erp_module10_alumni_onlineexam_certificates.zip | Alumni / Online Exam |
| 13 | erp_module11_dashboard_class_attendance.zip | Dashboard + Class Attendance Report |

Files that appear in more than one zip (the last one you copy wins, and it contains everything):
`Stuattendence_model.php`, `Stuattendence.php` (Attendance, Reports, Module 11), `Receipt_model.php` (Module 2, 3),
`Income_model.php` / `Expense_model.php` (Module 4, 11).
If you apply in the order above you always end with the newest version.

## 3. What to test after installing
- Student Attendance: search a class/section, save attendance.
- Fees: Fee List / Fee Register with a date range and "all" per page; Defaulter List totals vs the old page for one class.
- Examinations: Tabulation and Percentage report for one class (marks, totals, grades).
- Income / Expense: Search Income for a range that ends on a day with entries (the last day is now included).
- HR: Staff Attendance Report for one month. Mail/SMS: send to a small group.
- Dashboard: charts and counters.

## 4. Not changed (and why)
Fees carry-forward, Mark entry, Timetable, Teacher pages, Cron job: small gains or higher risk; ask if one is slow.
Server-side DataTables for the big student/fee lists would be the next big step but is a larger project.
